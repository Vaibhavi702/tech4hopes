package com.tech4hope.screen.common;

import com.tech4hope.screen.common.login.LoginCustomerPage;
import com.tech4hope.screen.common.login.LoginDeliveryBoyPage;
import com.tech4hope.screen.common.login.LoginNgoPage;
import com.tech4hope.screen.common.login.LoginNgoWomenPage;

import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LoginPage  {

    public void show(Stage stage) {
        // ✅ Load background image
        Image backgroundImage = new Image(getClass().getResource("/images/login2.jpg").toExternalForm());

        BackgroundImage bgImage = new BackgroundImage(
            backgroundImage,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.CENTER,
            new BackgroundSize(100, 100, true, true, true, false)
        );

        // ✅ Title
        Label title = new Label("Login As");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 56));
        title.setTextFill(Color.WHITE);
        title.setEffect(new DropShadow(10, Color.FLORALWHITE));

        // ✅ Role Buttons
        Button customerBtn = createRoleButton("👩 Customer");
        Button deliveryBtn = createRoleButton("🚚 Delivery Boy");
        Button ngoBtn = createRoleButton("🏢 NGO");
        Button ngoWomenBtn = createRoleButton("👩‍🌾 NGO Women");

        // ✅ Add functionality to buttons
        customerBtn.setOnAction(e -> {
            try {
                new LoginCustomerPage().show(stage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        deliveryBtn.setOnAction(e -> {
            try {
                new LoginDeliveryBoyPage().show(stage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        ngoBtn.setOnAction(e -> {
            try {
                new LoginNgoPage().show(stage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        ngoWomenBtn.setOnAction(e -> {
            try {
                new LoginNgoWomenPage().show(stage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        VBox layout = new VBox(20, title, customerBtn, deliveryBtn, ngoBtn, ngoWomenBtn);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(40));
        layout.setMaxWidth(400);
        layout.setBackground(new Background(new BackgroundFill(
            Color.rgb(0, 0, 0, 0.5), new CornerRadii(20), Insets.EMPTY
        )));
        layout.setEffect(new DropShadow(20, Color.BLACK));

        // ✅ Fade In
        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1.5), layout);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);
        fadeIn.play();

        // ✅ Root
        StackPane root = new StackPane();
        root.setBackground(new Background(bgImage));

        // ✅ Gradient overlay
        Region overlay = new Region();
        overlay.setStyle("-fx-background-color: linear-gradient(to bottom, rgba(219, 96, 96, 0.3), rgba(203, 121, 121, 0.7));");
        overlay.setPrefSize(850, 550);

        root.getChildren().addAll(overlay, layout);

        Scene scene = new Scene(root, 850, 550);
        stage.setTitle("HopeBridge - Login");
        stage.setScene(scene);
        stage.show();
    }

    private Button createRoleButton(String text) {
        Button button = new Button(text);
        button.setFont(Font.font("Segoe UI", FontWeight.MEDIUM, 30));
        button.setPrefWidth(280);
        button.setStyle("-fx-background-color: #11f619ff; -fx-text-fill: white; -fx-background-radius: 10;");

        // Hover pop animation
        button.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.1);
            st.setToY(1.1);
            st.play();
        });

        button.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.0);
            st.setToY(1.0);
            st.play();
        });

        return button;
    }
}
