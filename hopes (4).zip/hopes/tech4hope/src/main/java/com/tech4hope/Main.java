package com.tech4hope;





import com.tech4hope.screen.common.LandingPage;
import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(LandingPage.class, args); // ✅ Correct
    }
}

