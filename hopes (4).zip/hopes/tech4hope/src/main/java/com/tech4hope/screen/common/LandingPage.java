package com.tech4hope.screen.common;

import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LandingPage extends Application {

    
    public void start (Stage stage) {
        // ✅ NGO Women background image
        Image backgroundImage = new Image(getClass().getResource("/images/landingpage.jpeg").toExternalForm());


        BackgroundImage bgImage = new BackgroundImage(
            backgroundImage,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.CENTER,
            new BackgroundSize(100, 100, true, true, true, false)
        );

        Label title = new Label("HopeBridge");
        title.setFont(Font.font("Georgia", FontWeight.EXTRA_BOLD, 54));
        title.setTextFill(Color.web("#FFFDE7"));
        title.setEffect(new DropShadow(8, Color.web("#2E7D32")));

        Label tagline = new Label("Empowering Women • Cultivating Community");
        tagline.setFont(Font.font("Segoe UI", FontWeight.SEMI_BOLD, 20));
        tagline.setTextFill(Color.web("#FAFAFA"));

        Label symbols = new Label("🌸 🌿 🤝 📚 🌞");
        symbols.setFont(Font.font(32));
        symbols.setTextFill(Color.web("#E0F2F1"));

        Button signIn = createPopButton("Sign In", "#FF9800");
        Button signUp = createPopButton("Sign Up", "#4CAF50");

        // 🔁 Transitions to LoginPage
        signIn.setOnAction(e -> {
            FadeTransition fadeOut = new FadeTransition(Duration.seconds(0.5), stage.getScene().getRoot());
            fadeOut.setFromValue(1);
            fadeOut.setToValue(0);
            fadeOut.setOnFinished(event -> {
                try {
                    new LoginPage().show(stage);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });
            fadeOut.play();
        });

        // 🔁 Transitions to SignupPage
        signUp.setOnAction(e -> {
            FadeTransition fadeOut = new FadeTransition(Duration.seconds(0.5), stage.getScene().getRoot());
            fadeOut.setFromValue(1);
            fadeOut.setToValue(0);
            fadeOut.setOnFinished(event -> {
                try {
                    new SignupPage().show(stage);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });
            fadeOut.play();
        });

        HBox buttonBox = new HBox(30, signIn, signUp);
        buttonBox.setAlignment(Pos.CENTER);

        VBox content = new VBox(20, title, tagline, symbols, buttonBox);
        content.setAlignment(Pos.CENTER);
        content.setPadding(new Insets(40));
        content.setBackground(new Background(new BackgroundFill(
            Color.rgb(0, 0, 0, 0.4), new CornerRadii(15), Insets.EMPTY
        )));

        FadeTransition fade = new FadeTransition(Duration.seconds(2), content);
        fade.setFromValue(0);
        fade.setToValue(1);
        fade.play();

        StackPane root = new StackPane();
        root.setBackground(new Background(bgImage));
        root.getChildren().add(content);

        Scene scene = new Scene(root, 850, 550);
        stage.setTitle("HopeBridge - Landing Page");
        stage.setScene(scene);
        stage.show();
    }

    // 🌟 Button with hover animation
    private Button createPopButton(String text, String color) {
        Button button = new Button(text);
        button.setPrefWidth(160);
        button.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; -fx-background-radius: 10;");

        button.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.1);
            st.setToY(1.1);
            st.play();
        });

        button.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.0);
            st.setToY(1.0);
            st.play();
        });

        return button;
    }

    public static void main(String[] args) {
        launch();
    }
}
