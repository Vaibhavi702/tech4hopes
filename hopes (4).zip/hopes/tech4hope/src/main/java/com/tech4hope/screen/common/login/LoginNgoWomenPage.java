package com.tech4hope.screen.common.login;





import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LoginNgoWomenPage  {

    
    public void show(Stage stage) {
        // 🌄 Background Image
        Image backgroundImage = new Image(getClass().getResource("/images/login2.jpg").toExternalForm());
        BackgroundImage bgImage = new BackgroundImage(
            backgroundImage,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.CENTER,
            new BackgroundSize(100, 100, true, true, true, false)
        );

        // 🧾 Title
        Label title = new Label("NGO WOMEN Login");
        title.setFont(Font.font("Georgia", FontWeight.BOLD, 38));
        title.setTextFill(Color.WHITE);
        title.setEffect(new DropShadow(8, Color.DARKGREEN));

        // 📨 Email
        TextField emailField = new TextField();
        emailField.setPromptText("Enter Email");
        emailField.setMaxWidth(300);
        styleInput(emailField);

        // 🔒 Password
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter Password");
        passwordField.setMaxWidth(300);
        styleInput(passwordField);

        // 🔘 Login Button
        Button loginBtn = createPopButton("Login", "#43A047");

        // 🔙 Back Button
        Button backBtn = createPopButton("← Back", "#9E9E9E");
        backBtn.setOnAction(e -> {
            try {
                new com.tech4hope.screen.common.LoginPage().show(stage); // navigate to role selection
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        VBox layout = new VBox(15, title, emailField, passwordField, loginBtn, backBtn);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(30));
        layout.setBackground(new Background(new BackgroundFill(
            Color.rgb(0, 0, 0, 0.6), new CornerRadii(15), Insets.EMPTY
        )));

        FadeTransition fade = new FadeTransition(Duration.seconds(1.5), layout);
        fade.setFromValue(0);
        fade.setToValue(1);
        fade.play();

        StackPane root = new StackPane();
        root.setBackground(new Background(bgImage));
        root.getChildren().add(layout);

        Scene scene = new Scene(root, 850, 550);
        stage.setScene(scene);
        stage.setTitle("HopeBridge - NGO WOMEN Login");
        stage.show();
    }

    private void styleInput(TextField field) {
        field.setStyle(
            "-fx-background-radius: 8; -fx-background-color: #ffffffcc; -fx-padding: 10;" +
            "-fx-font-size: 14px; -fx-text-fill: #000;"
        );
    }

    private Button createPopButton(String text, String color) {
        Button button = new Button(text);
        button.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        button.setPrefWidth(200);
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; -fx-background-radius: 10;");

        button.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.1);
            st.setToY(1.1);
            st.play();
        });

        button.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.0);
            st.setToY(1.0);
            st.play();
        });

        return button;
    }

}

    



