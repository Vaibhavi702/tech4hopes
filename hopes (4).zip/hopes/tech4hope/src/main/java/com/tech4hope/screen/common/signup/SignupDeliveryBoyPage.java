package com.tech4hope.screen.common.signup;

import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;

public class SignupDeliveryBoyPage  {

    
    public void show(Stage stage) {
        // 🔹 Background image
        Image bgImg = new Image(getClass().getResource("/images/login2.jpg").toExternalForm());
        BackgroundImage backgroundImage = new BackgroundImage(
            bgImg,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.CENTER,
            new BackgroundSize(100, 100, true, true, true, false)
        );

        // 🔹 Title
        Label title = new Label("DeliveryBoy Sign Up");
        title.setFont(Font.font("Georgia", FontWeight.BOLD, 36));
        title.setTextFill(Color.WHITE);
        title.setEffect(new DropShadow(5, Color.DARKGREEN));

        // 🔹 Form Fields
        TextField fullName = new TextField();
        fullName.setPromptText("Full Name");

        TextField email = new TextField();
        email.setPromptText("Email");

        PasswordField password = new PasswordField();
        password.setPromptText("Password");

        PasswordField confirmPassword = new PasswordField();
        confirmPassword.setPromptText("Confirm Password");

        // 🔹 Buttons
        Button signUpBtn = createButton("Sign Up", "#4CAF50");
        Button backBtn = createButton("← Back", "#9E9E9E");

        // Back button action (return to role selection)
        backBtn.setOnAction(e -> {
            try {
                new com.tech4hope.screen.common.SignupPage().show(stage);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        VBox form = new VBox(15, title, fullName, email, password, confirmPassword, signUpBtn, backBtn);
        form.setAlignment(Pos.CENTER);
        form.setPadding(new Insets(30));
        form.setMaxWidth(350);
        form.setBackground(new Background(new BackgroundFill(
            Color.rgb(0, 0, 0, 0.5), new CornerRadii(20), Insets.EMPTY
        )));
        form.setEffect(new DropShadow(20, Color.BLACK));

        // 🔹 Fade in effect
        FadeTransition fade = new FadeTransition(Duration.seconds(1.5), form);
        fade.setFromValue(0);
        fade.setToValue(1);
        fade.play();

        // 🔹 Root
        StackPane root = new StackPane();
        root.setBackground(new Background(backgroundImage));
        root.getChildren().add(form);

        Scene scene = new Scene(root, 850, 550);
        stage.setTitle("HopeBridge - Sign Up as DeliveryBoy");
        stage.setScene(scene);
        stage.show();
    }

    // 🔁 Button with animation
    private Button createButton(String text, String color) {
        Button button = new Button(text);
        button.setFont(Font.font("Segoe UI", FontWeight.BOLD, 16));
        button.setPrefWidth(200);
        button.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; -fx-background-radius: 8;");

        button.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.1);
            st.setToY(1.1);
            st.play();
        });

        button.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.0);
            st.setToY(1.0);
            st.play();
        });

        return button;
    }

}
