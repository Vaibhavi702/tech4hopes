package com.tech4hope.screen.common;

import com.tech4hope.screen.common.signup.SignupCustomerPage;
import com.tech4hope.screen.common.signup.SignupDeliveryBoyPage;
import com.tech4hope.screen.common.signup.SignupNgoPage;
import com.tech4hope.screen.common.signup.SignupNgoWomenPage;

import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.util.Duration;

public class SignupPage {

    public void show(Stage stage) {
        // ✅ Background Image
        Image backgroundImage = new Image(getClass().getResource("/images/login2.jpg").toExternalForm());
        BackgroundImage bgImage = new BackgroundImage(
            backgroundImage,
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.CENTER,
            new BackgroundSize(100, 100, true, true, true, false)
        );

        Label title = new Label("Sign Up As");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 56));
        title.setTextFill(Color.WHITE);
        title.setEffect(new DropShadow(10, Color.DARKGREEN));

        // ✅ Buttons with event handling
        Button customerBtn = createRoleButton("\uD83D\uDC69 Customer", stage, new SignupCustomerPage());
        Button deliveryBtn = createRoleButton("\uD83D\uDE9A Delivery Boy", stage, new SignupDeliveryBoyPage());
        Button ngoBtn = createRoleButton("\uD83C\uDFE2 NGO", stage, new SignupNgoPage());
        Button ngoWomenBtn = createRoleButton("\uD83D\uDC69‍\uD83C\uDF3E NGO Women", stage, new SignupNgoWomenPage());

        VBox layout = new VBox(20, title, customerBtn, deliveryBtn, ngoBtn, ngoWomenBtn);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(40));
        layout.setMaxWidth(400);
        layout.setBackground(new Background(new BackgroundFill(
            Color.rgb(0, 0, 0, 0.5), new CornerRadii(20), Insets.EMPTY
        )));
        layout.setEffect(new DropShadow(20, Color.BLACK));

        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1.5), layout);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);
        fadeIn.play();

        StackPane root = new StackPane();
        root.setBackground(new Background(bgImage));

        Region overlay = new Region();
        overlay.setStyle("-fx-background-color: linear-gradient(to bottom, rgba(96, 178, 219, 0.3), rgba(96, 178, 219, 0.7));");
        overlay.setPrefSize(850, 550);

        root.getChildren().addAll(overlay, layout);

        Scene scene = new Scene(root, 850, 550);
        stage.setTitle("HopeBridge - Sign Up");
        stage.setScene(scene);
        stage.show();
    }

    private Button createRoleButton(String text, Stage stage, Object nextPage) {
        Button button = new Button(text);
        button.setFont(Font.font("Segoe UI", FontWeight.MEDIUM, 30));
        button.setPrefWidth(280);
        button.setStyle("-fx-background-color: #008CBA; -fx-text-fill: white; -fx-background-radius: 10;");

        button.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.1);
            st.setToY(1.1);
            st.play();
        });

        button.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(150), button);
            st.setToX(1.0);
            st.setToY(1.0);
            st.play();
        });

        button.setOnAction(e -> {
            FadeTransition fadeOut = new FadeTransition(Duration.seconds(0.5), stage.getScene().getRoot());
            fadeOut.setFromValue(1);
            fadeOut.setToValue(0);
            fadeOut.setOnFinished(event -> {
                try {
                    nextPage.getClass().getMethod("show", Stage.class).invoke(nextPage, stage);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });
            fadeOut.play();
        });

        return button;
    }
}
