package com.bts.view.login;


import com.bts.service.AuthController;
import com.bts.service.FirebaseAuthController;
import com.bts.view.Restaurant.RestaurantDashboardPage;

import com.bts.view.signup.RestaurantSignupPage;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class RestaurantLoginPage {

    private final VBox root;

    public RestaurantLoginPage() {
        root = new VBox(30);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(60));
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #6A1B9A, #AD1457);"); // NGO themed gradient

        // Title - bigger and attractive
        Label title = new Label("NGO Women Login");
        title.setFont(Font.font("Arial", 50)); // bigger title
        title.setTextFill(Color.WHITE);
        title.setStyle("-fx-font-weight: bold;");

        // Glow effect for title
        DropShadow titleShadow = new DropShadow();
        titleShadow.setColor(Color.PINK);
        titleShadow.setRadius(30);
        title.setEffect(titleShadow);

        // Fields
        TextField email = new TextField();
        email.setPromptText("Email");
        email.setMaxWidth(350);
        email.setStyle("-fx-font-size: 18px; -fx-padding: 12; -fx-background-radius: 10;");

        PasswordField password = new PasswordField();
        password.setPromptText("Password");
        password.setMaxWidth(350);
        password.setStyle("-fx-font-size: 18px; -fx-padding: 12; -fx-background-radius: 10;");

        // Buttons
        Button loginBtn = new Button("Login");
        styleButton(loginBtn, "#F06292"); // pink NGO theme
        loginBtn.setOnAction(e -> {
             AuthController auth=new AuthController(email.getText());
             FirebaseAuthController.loginWithEmailAndPassword(email.getText(), password.getText());
            System.out.println("Customer logged in: " + email.getText());
            try {
                new RestaurantDashboardPage().show((Stage) root.getScene().getWindow());
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        });

        Button signupBtn = new Button("Create Account");
        styleButton(signupBtn, "#BA68C8"); // purple NGO theme
        signupBtn.setOnAction(e -> {
            new RestaurantSignupPage().show((Stage) root.getScene().getWindow());
        });

        root.getChildren().addAll(title, email, password, loginBtn, signupBtn);
    }

    private void styleButton(Button btn, String color) {
        btn.setStyle(
                "-fx-font-size: 22px;" + // bigger font
                        "-fx-background-radius: 40px;" +
                        "-fx-padding: 18 60;" + // bigger button
                        "-fx-background-color: " + color + ";" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;"
        );
        btn.setEffect(new DropShadow(15, Color.DARKGRAY));
        btn.setMaxWidth(400);
    }

    public void show(Stage stage) {
        Scene scene = new Scene(root, 1900, 1000);
        stage.setScene(scene);
        stage.setTitle("HopeBridge - NGO  Women Login");
        stage.show();
    }
}
