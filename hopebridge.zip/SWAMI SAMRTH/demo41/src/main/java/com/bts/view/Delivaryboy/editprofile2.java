package com.bts.view.Delivaryboy;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class editprofile2 {

    public void show(Stage stage) {
        // ===== Root Layout =====
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #f8f8f8;");

        // ===== Back Button (Top-Left) =====
        Button backBtn = new Button("← Back");
        backBtn.setStyle(
                "-fx-background-color: transparent; -fx-text-fill: #2980b9; " +
                "-fx-font-size: 18px; -fx-font-weight: bold;"
        );
        backBtn.setOnAction(e -> {
            // Navigate to Delivery Boy Dashboard
            new DeliveryBoyDashboardPage().show(stage);
        });

        HBox topBar = new HBox(backBtn);
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setPadding(new Insets(20, 0, 0, 20));

        // ===== Center Content =====
        VBox centerContent = new VBox(25);
        centerContent.setAlignment(Pos.CENTER);
        centerContent.setPadding(new Insets(40));

        // Title
        Text title = new Text("Edit Delivery Boy Profile");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 40));
        title.setFill(Color.DARKBLUE);

        // Profile Image Circle (placeholder)
        Circle profileCircle = new Circle(100);
        profileCircle.setFill(Color.LIGHTGRAY);
        Label imgLabel = new Label("Profile\nImage");
        imgLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        imgLabel.setTextFill(Color.DARKGRAY);
        StackPane profileImageStack = new StackPane(profileCircle, imgLabel);

        // Fields (match CreateProfilePage1 fields)
        VBox nameBox = createField("Full Name");
        VBox emailBox = createField("Email");
        VBox phoneBox = createField("Phone Number");
        VBox vehicleBox = createField("Vehicle Number");
        VBox cityBox = createField("City / Area");

        // Save Changes Button
        Button saveBtn = new Button("Save Changes");
        saveBtn.setPrefWidth(350);
        saveBtn.setPrefHeight(55);
        saveBtn.setStyle(
                "-fx-background-color: #e67e22; -fx-text-fill: white; " +
                "-fx-font-size: 20px; -fx-font-weight: bold; -fx-background-radius: 12;"
        );

        // Add components to center content
        centerContent.getChildren().addAll(
                title, profileImageStack,
                nameBox, emailBox, phoneBox, vehicleBox, cityBox,
                saveBtn
        );

        root.setTop(topBar);
        root.setCenter(centerContent);

        // Scene 1900x1000
        Scene scene = new Scene(root, 1900, 1000);
        stage.setTitle("Delivery Boy - Edit Profile");
        stage.setScene(scene);
        stage.show();
    }

    // Helper method for fields
    private VBox createField(String labelText) {
        Label label = new Label(labelText);
        label.setStyle("-fx-font-weight: bold; -fx-font-size: 18px;");
        TextField textField = new TextField();
        textField.setPromptText(labelText);
        textField.setMaxWidth(600);
        textField.setStyle(
                "-fx-background-color: transparent; -fx-border-color: gray; " +
                "-fx-border-width: 0 0 2 0; -fx-font-size: 18px;"
        );
        VBox box = new VBox(8, label, textField);
        box.setAlignment(Pos.CENTER);
        return box;
    }
}
