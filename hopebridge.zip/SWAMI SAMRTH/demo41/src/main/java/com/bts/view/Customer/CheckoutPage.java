package com.bts.view.Customer;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class CheckoutPage {

    public void show(Stage stage) {

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #fcfcfc;");

        // ===== TOP NAVBAR =====
        HBox navbar = new HBox(30);
        navbar.setPadding(new Insets(30, 50, 30, 50));
        navbar.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e6e6e6; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 6, 0, 0, 2);");
        navbar.setAlignment(Pos.CENTER_LEFT);

        Label back = new Label("← Back");
        back.setFont(Font.font("Arial", 26));
        back.setTextFill(Color.ORANGE);

        Label title = new Label("Checkout");
        title.setFont(Font.font("Arial", 34));
        title.setTextFill(Color.ORANGE);

        navbar.getChildren().addAll(back, title);

        // Back navigation to CartPage
        back.setOnMouseClicked(e -> {
            new CartPage().show(stage);
        });

        // ===== CENTER LAYOUT =====
        VBox centerLayout = new VBox(40); // more spacing between sections
        centerLayout.setPadding(new Insets(40));
        centerLayout.setAlignment(Pos.TOP_CENTER);

        // ===== Delivery Address Section =====
        VBox addressBox = new VBox(15);
        addressBox.setStyle("-fx-border-color: #e6e6e6; -fx-background-color: #ffffff; -fx-background-radius: 15; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.05), 8, 0, 0, 2);");
        addressBox.setPadding(new Insets(30));
        addressBox.setPrefWidth(800);

        Label addressTitle = new Label("Delivery Address");
        addressTitle.setFont(Font.font("Arial", 26));

        Label addressLabel = new Label("123, ABC Street, Pune - 411045");
        addressLabel.setFont(Font.font("Arial", 22));

        Button changeAddress = new Button("Change");
        changeAddress.setStyle("-fx-background-color: orange; -fx-text-fill: white; -fx-font-size: 18; -fx-font-weight: bold; -fx-background-radius: 8;");
        changeAddress.setPrefWidth(180);
        changeAddress.setPrefHeight(50);

        addressBox.getChildren().addAll(addressTitle, addressLabel, changeAddress);

        // ===== Payment Section =====
        VBox paymentBox = new VBox(20);
        paymentBox.setStyle("-fx-border-color: #e6e6e6; -fx-background-color: #ffffff; -fx-background-radius: 15; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.05), 8, 0, 0, 2);");
        paymentBox.setPadding(new Insets(30));
        paymentBox.setPrefWidth(800);

        Label paymentTitle = new Label("Payment Method");
        paymentTitle.setFont(Font.font("Arial", 26));

        ToggleGroup paymentGroup = new ToggleGroup();

        RadioButton cod = new RadioButton("Cash on Delivery");
        cod.setFont(Font.font("Arial", 22));
        cod.setToggleGroup(paymentGroup);
        cod.setSelected(true);

        RadioButton upi = new RadioButton("UPI / Google Pay");
        upi.setFont(Font.font("Arial", 22));
        upi.setToggleGroup(paymentGroup);

        RadioButton card = new RadioButton("Credit / Debit Card");
        card.setFont(Font.font("Arial", 22));
        card.setToggleGroup(paymentGroup);

        paymentBox.getChildren().addAll(paymentTitle, cod, upi, card);

        // ===== Place Order Button =====
        Button placeOrderBtn = new Button("Place Order");
        placeOrderBtn.setPrefWidth(800);
        placeOrderBtn.setPrefHeight(70);
        placeOrderBtn.setStyle("-fx-background-color: green; -fx-text-fill: white; -fx-font-size: 24; -fx-font-weight: bold; -fx-background-radius: 10;");

        // Hover effect
        placeOrderBtn.setOnMouseEntered(e -> placeOrderBtn.setStyle("-fx-background-color: #0d8c0d; -fx-text-fill: white; -fx-font-size: 24; -fx-font-weight: bold; -fx-background-radius: 10;"));
        placeOrderBtn.setOnMouseExited(e -> placeOrderBtn.setStyle("-fx-background-color: green; -fx-text-fill: white; -fx-font-size: 24; -fx-font-weight: bold; -fx-background-radius: 10;"));

        placeOrderBtn.setOnAction(e -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Order Placed");
            alert.setHeaderText("Success");
            alert.setContentText("Your order has been placed successfully!");
            alert.showAndWait();

            // Redirect to Dashboard after placing order
            try {
                new CustomerDashboardPage().show(stage);
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        });

        centerLayout.getChildren().addAll(addressBox, paymentBox, placeOrderBtn);

        // Add all to root
        root.setTop(navbar);
        root.setCenter(centerLayout);

        Scene scene = new Scene(root,  1900, 1000); // Larger window
        stage.setScene(scene);
        stage.setTitle("Checkout Page");
        stage.show();
    }
}
