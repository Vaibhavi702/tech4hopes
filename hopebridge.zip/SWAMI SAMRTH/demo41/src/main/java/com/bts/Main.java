package com.bts;

import javafx.application.Application;
import com.bts.LandingPage;
import com.bts.service.FirebaseUtil;


public class Main {
    public static void main(String[] args) throws Exception {
     FirebaseUtil.initializeFirebase();
         Application.launch(LandingPage.class,args);
    }

    }
