package com.bts.view.Restaurant;

import java.util.Map;

import com.bts.service.firebaseconfig;
import com.google.api.services.storage.model.StorageObject;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class editprofile3 {

    public void show(Stage stage) throws Exception {
          Map<String,Object>data=firebaseconfig.readProfile();
        // ===== Root Layout =====
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #f9f9fc, #e6ecf5);");

        // ===== Back Button (Top-Left) =====
        Button backBtn = new Button("← Back");
        backBtn.setStyle(
                "-fx-background-color: transparent; -fx-text-fill: #2980b9; " +
                        "-fx-font-size: 18px; -fx-font-weight: bold;"
        );
        backBtn.setOnAction(e -> {
            try {
                new RestaurantDashboardPage().show(stage);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });

        HBox topBar = new HBox(backBtn);
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setPadding(new Insets(20, 0, 0, 20));

        // ===== Center Content =====
        VBox centerContent = new VBox(30);
        centerContent.setAlignment(Pos.CENTER);
        centerContent.setPadding(new Insets(50));

        // Title
        Text title = new Text("NGO Women Profile");
        title.setFont(Font.font("Arial", FontWeight.EXTRA_BOLD, 42));
        title.setFill(Color.web("#2c3e50"));

        // Bigger Profile Image Circle (placeholder)
        Circle profileCircle = new Circle(100);
        profileCircle.setFill(Color.LIGHTGRAY);
        Text imgLabel = new Text("Profile\nImage");
        imgLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        imgLabel.setFill(Color.DARKGRAY);
        StackPane profileImageStack = new StackPane(profileCircle, imgLabel);

        // Profile Data (Only labels)
        VBox detailsBox = new VBox(20);
        detailsBox.setAlignment(Pos.CENTER_LEFT);
        detailsBox.setPadding(new Insets(20));
        detailsBox.setMaxWidth(600);
        detailsBox.setStyle(
                "-fx-background-color: white; -fx-background-radius: 15; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 8, 0, 2, 2);"
        );
        System.out.println((String) data.get("name"));
         System.out.println((String) data.get("email"));
          System.out.println((String) data.get("phn"));
          
        detailsBox.getChildren().addAll(
                createInfoRow("Full Name:",(String) data.get("name")),
                createInfoRow("Email:", (String)data.get("email")),
                createInfoRow("Phone Number:", (String)data.get("phn")),
                createInfoRow("Skills / Expertise:", (String)data.get("skill")),
                createInfoRow("NGO Name:", (String)data.get("Name")),
                createInfoRow("Location / Address:", (String)data.get("location"))
        );

        centerContent.getChildren().addAll(title, profileImageStack, detailsBox);

        root.setTop(topBar);
        root.setCenter(centerContent);

        // Scene
        Scene scene = new Scene(root, 1900, 1000);
        stage.setTitle("NGO Women - Profile");
        stage.setScene(scene);
        stage.show();
    }

    private HBox createInfoRow(String labelText, String valueText) {
        Text label = new Text(labelText);
        label.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        label.setFill(Color.web("#34495e"));

        Text value = new Text(valueText);
        value.setFont(Font.font("Arial", FontWeight.NORMAL, 20));
        value.setFill(Color.web("#2c3e50"));

        HBox row = new HBox(15, label, value);
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }
}
