package com.bts.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;

public class firebaseconfig {

    public static void storePlayer(String name, String price,String type,String rating, String add) throws Exception {
        Map<String, Object> playerData = new HashMap<>();
        playerData.put("name", name);
        playerData.put("price",price);
        playerData.put("type",type);
         playerData.put("rating",rating);
          playerData.put("address",add);
       FirebaseUtil.db.collection("ngo").document(AuthController.getEmail()).collection("upload").document().set(playerData);
    }


   public static List<Map<String, Object>> getAllRestaurants() throws Exception {
    ApiFuture<QuerySnapshot> future = FirebaseUtil.db.collection("ngo").document(AuthController.getEmail()).collection("upload").get();
    List<QueryDocumentSnapshot> documents = future.get().getDocuments();

    List<Map<String, Object>> restaurantList = new ArrayList<>();
    for (QueryDocumentSnapshot document : documents) {
        restaurantList.add(document.getData());
    }
    return restaurantList;
  
}

public static void storeProd(String name, String address,String price,String rating) throws Exception {
        Map<String, Object> playerData = new HashMap<>();
        playerData.put("name", name);
        playerData.put("address",address);
        playerData.put("price",price);
                playerData.put("rating",rating);
       FirebaseUtil. db.collection("customer").document(AuthController.getEmail()).collection("addtocard").document().set(playerData);
    }

   public static List<Map<String, Object>> getAllProductsForCustomer() throws Exception {
    // Get the logged-in customer email as document ID
    String customerEmail = AuthController.getEmail();

    // Query the subcollection 'prod' of this customer
    ApiFuture<QuerySnapshot> future = FirebaseUtil.db
            .collection("customer")
            .document(customerEmail)
            .collection("addtocard")
            .get();

    List<QueryDocumentSnapshot> documents = future.get().getDocuments();

    List<Map<String, Object>> productList = new ArrayList<>();
    for (QueryDocumentSnapshot document : documents) {
        // You can also include document ID if needed
        Map<String, Object> data = document.getData();
        data.put("id", document.getId()); // Add the document ID for reference
        productList.add(data);
    }
    return productList;
}



public static void storeProfile(String name, String email,String phn,String skill,String Name, String location) throws Exception {
        Map<String, Object> playerData = new HashMap<>();
        playerData.put("name", name);
        playerData.put("email",email);
        playerData.put("phn",phn);
        playerData.put("skill",skill);
         playerData.put("Name",Name);
        playerData.put("location",location);

       FirebaseUtil.db.collection("ngo").document(AuthController.getEmail()).set(playerData);
    }

    public static Map<String, Object> readProfile() throws Exception {
        DocumentSnapshot document = FirebaseUtil.db.collection("ngo").document(AuthController.getEmail()).get().get();
        if (document.exists()) {
            return document.getData();
        } else {
            return null;
        }
    }
}

