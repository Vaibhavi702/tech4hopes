package com.bts.view.signup;

import com.bts.service.AuthController;
import com.bts.service.FirebaseAuthController;
import com.bts.view.Customer.CreateProfilePage;
import com.bts.view.login.CustomerLoginPage;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class CustomerSignupPage {

    private final VBox root;

    public CustomerSignupPage() {
        root = new VBox(30);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(60));
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #6A1B9A, #AD1457);"); // NGO Women theme

        // Title - Changed for NGO Women
        Label title = new Label("Customer Signup");
        title.setFont(Font.font("Arial", 50));
        title.setTextFill(Color.WHITE);
        title.setStyle("-fx-font-weight: bold;");

        // Glow effect for title
        DropShadow titleShadow = new DropShadow();
        titleShadow.setColor(Color.PINK);
        titleShadow.setRadius(30);
        title.setEffect(titleShadow);

        // Fields - Bigger & rounded
        TextField email = new TextField();
        email.setPromptText("Email");
        email.setMaxWidth(350);
        email.setStyle("-fx-font-size: 18px; -fx-padding: 12; -fx-background-radius: 10;");

        PasswordField password = new PasswordField();
        password.setPromptText("Password");
        password.setMaxWidth(350);
        password.setStyle("-fx-font-size: 18px; -fx-padding: 12; -fx-background-radius: 10;");

        PasswordField confirmPassword = new PasswordField();
        confirmPassword.setPromptText("Confirm Password");
        confirmPassword.setMaxWidth(350);
        confirmPassword.setStyle("-fx-font-size: 18px; -fx-padding: 12; -fx-background-radius: 10;");

        // Buttons - NGO Women colors
        Button signupBtn = new Button("Sign Up");
        styleButton(signupBtn, "#F06292"); // pink NGO color
        signupBtn.setOnAction(e -> {
            AuthController auth=new AuthController(email.getText());
            FirebaseAuthController.signUp(email.getText(), password.getText());
            System.out.println("NGO Women account created: " + email.getText());
            new CreateProfilePage().show((Stage) root.getScene().getWindow());
            
        
        });
       
            ;

        Button loginBtn = new Button("Already Have Account? Login");
        styleButton(loginBtn, "#BA68C8"); // purple NGO color
        loginBtn.setOnAction(e -> {
            // Temporarily navigating to DeliveryBoyLoginPage, you can link NGO Women Login page later
            new CustomerLoginPage().show((Stage) root.getScene().getWindow());
        });

        root.getChildren().addAll(title, email, password, confirmPassword, signupBtn, loginBtn);
    }

    private void styleButton(Button btn, String color) {
        btn.setStyle(
                "-fx-font-size: 22px;" + // bigger font
                        "-fx-background-radius: 40px;" +
                        "-fx-padding: 18 60;" +
                        "-fx-background-color: " + color + ";" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;"
        );
        btn.setEffect(new DropShadow(15, Color.DARKGRAY));
        btn.setMaxWidth(400);
    }

    public void show(Stage stage) {
        Scene scene = new Scene(root, 1900, 1000);
        stage.setScene(scene);
        stage.setTitle("HopeBridge - Customer Sign Up");
        stage.show();
    }
}
