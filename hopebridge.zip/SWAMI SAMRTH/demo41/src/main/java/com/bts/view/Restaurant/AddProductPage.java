package com.bts.view.Restaurant;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

import com.bts.service.firebaseconfig;

public class AddProductPage {

    public void show(Stage stage) {
        // Root layout
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #1e0932; -fx-padding: 40;");

        // ================= HEADER =================
        HBox header = new HBox(20);
        header.setAlignment(Pos.CENTER_LEFT);

        Label title = new Label("➕ Add Handmade Product");
        title.setTextFill(Color.WHITE);
        title.setFont(new Font("Arial", 32));

        Button backBtn = new Button("⬅ Back");
        styleSmallButton(backBtn, "gray");
        backBtn.setOnAction(e -> {
            try {
                new RestaurantDashboardPage().show(stage);
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        });

        header.getChildren().addAll(backBtn, title);
        root.setTop(header);
        BorderPane.setMargin(header, new Insets(20, 20, 30, 20));

        // ================= MAIN CONTENT =================
        HBox mainContent = new HBox(60);
        mainContent.setAlignment(Pos.CENTER);
        mainContent.setPadding(new Insets(50));
        mainContent.setStyle("-fx-background-color: #2b1243; -fx-background-radius: 20;");
        mainContent.setMaxWidth(1000); // Center block width
        mainContent.setPrefHeight(500); // Center block height

        // Center the mainContent in the screen
        StackPane centerContainer = new StackPane(mainContent);
        centerContainer.setAlignment(Pos.CENTER);
        root.setCenter(centerContainer);

        // ===== LEFT: IMAGE UPLOAD & PREVIEW =====
        VBox leftBox = new VBox(20);
        leftBox.setAlignment(Pos.CENTER);

        Label imgLabel = new Label("Image Preview");
        imgLabel.setTextFill(Color.WHITE);
        imgLabel.setFont(new Font(18));

        StackPane imgContainer = new StackPane();
        imgContainer.setPrefSize(300, 250); // Bigger preview box
        imgContainer.setStyle("-fx-background-color: white; -fx-background-radius: 12;");

        ImageView preview = new ImageView();
        preview.setFitWidth(280);
        preview.setFitHeight(230);
        imgContainer.getChildren().add(preview);

        Button uploadBtn = new Button("📂 Choose Image");
        styleSmallButton(uploadBtn, "orange");
        uploadBtn.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.jpeg"));
            File selected = fileChooser.showOpenDialog(stage);
            if (selected != null) {
                preview.setImage(new Image(selected.toURI().toString()));
            }
        });

        leftBox.getChildren().addAll(imgLabel, imgContainer, uploadBtn);

        // ===== RIGHT: FORM FIELDS =====
        VBox formBox = new VBox(25);
        formBox.setAlignment(Pos.CENTER_LEFT);

        TextField nameField = createInputField("Product Name");
        TextField priceField = createInputField("Price");
        TextField rating = createInputField("Rating");
        TextField address = createInputField("Adress");



        // Handmade/Other toggle (optional, for category)
        Label typeLabel = new Label("Category");
        typeLabel.setTextFill(Color.WHITE);
        typeLabel.setFont(new Font(18));

        ToggleGroup categoryGroup = new ToggleGroup();
        RadioButton handmadeBtn = new RadioButton("Handmade");
        RadioButton otherBtn = new RadioButton("Other");
        handmadeBtn.setTextFill(Color.WHITE);
        otherBtn.setTextFill(Color.WHITE);
        handmadeBtn.setToggleGroup(categoryGroup);
        otherBtn.setToggleGroup(categoryGroup);
        handmadeBtn.setSelected(true);
        HBox typeBox = new HBox(20, handmadeBtn, otherBtn);

        Button saveBtn = new Button("✅ Save Product");
        styleBigButton(saveBtn, "#4CAF50");
        saveBtn.setOnAction(e -> {
            try {
                firebaseconfig.storePlayer(nameField.getText(),priceField.getText(),"Handmade",rating.getText(),address.getText());
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
       
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Product Added Successfully!");
            alert.showAndWait();
            nameField.clear();
            priceField.clear();
            preview.setImage(null);
            handmadeBtn.setSelected(true);
        });

        formBox.getChildren().addAll(nameField, priceField, typeLabel, typeBox, saveBtn);

        // Combine in HBox
        mainContent.getChildren().addAll(leftBox, formBox);

        // Scene
        Scene scene = new Scene(root,  1900, 1000); // Full-screen feel
        stage.setTitle("Add Handmade Product");
        stage.setScene(scene);
        stage.show();
    }

    // ================= HELPERS =================
    private TextField createInputField(String prompt) {
        TextField field = new TextField();
        field.setPromptText(prompt);
        field.setPrefWidth(320);
        field.setPrefHeight(45);
        field.setStyle("-fx-background-radius: 10; -fx-font-size: 16;");
        return field;
    }

    private void styleSmallButton(Button btn, String color) {
        btn.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; " +
                "-fx-font-size: 15; -fx-background-radius: 8; -fx-padding: 8 20;");
    }

    private void styleBigButton(Button btn, String color) {
        btn.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; " +
                "-fx-font-size: 18; -fx-background-radius: 12; -fx-padding: 12 30;");
    }
}

