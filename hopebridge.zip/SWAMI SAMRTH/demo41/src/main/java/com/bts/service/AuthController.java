package com.bts.service;

public class AuthController {
    private static String email;
    public AuthController(String email){
        this.email=email;
    }
    public static String getEmail() {
        return email;
    }
    
}