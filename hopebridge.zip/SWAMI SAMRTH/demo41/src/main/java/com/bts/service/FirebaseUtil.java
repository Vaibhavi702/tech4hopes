// File: FirebaseUtil.java
package com.bts.service;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;

import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

public class FirebaseUtil {

    public static Firestore db;

    // 🔹 Call this once during app startup
    public static void initializeFirebase() throws Exception {
        if (FirebaseApp.getApps().isEmpty()) { // Avoid re-initialization
            FileInputStream serviceAccount = new FileInputStream("demo41\\src\\main\\resources\\swiggy-372cc-firebase-adminsdk-fbsvc-f0805acfe4.json");
            FirebaseOptions options = new FirebaseOptions.Builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .build();
            FirebaseApp.initializeApp(options);
        }
        db = FirestoreClient.getFirestore();
    }

    // // 🔹 Store player data
    // public static void storePlayer(String name, int age) throws Exception {
    //     Map<String, Object> playerData = new HashMap<>();
    //     playerData.put("name", name);
    //     playerData.put("age", age);
    //     db.collection("Monika").document("raj").set(playerData).get();
    // }

    // // 🔹 Read player data
    // public static Map<String, Object> readPlayer() throws Exception {
    //     DocumentSnapshot document = db.collection("Monika").document("raj").get().get();
    //     if (document.exists()) {
    //         return document.getData();
    //     } else {
    //         return null;
    //     }
    // }
}