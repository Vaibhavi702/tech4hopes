package com.bts.view.Restaurant;
import com.bts.service.firebaseconfig;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.*;
import java.util.concurrent.ExecutionException;

public class OrdersPage {

    public void show(Stage stage) {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #1e0932; -fx-padding: 20;");

        // ===== HEADER =====
        HBox header = new HBox(30);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(20));

        Button backBtn = new Button("← Back");
        styleButton(backBtn, "orange", 160, 50);

        Label title = new Label("NGO Women Orders");
        title.setTextFill(Color.WHITE);
        title.setFont(new Font("Arial", 36));

        backBtn.setOnAction(e -> {
            try {
                new RestaurantDashboardPage().show(stage);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });
        header.getChildren().addAll(backBtn, title);
        root.setTop(header);

        // ===== Main Content =====
        VBox content = new VBox(30);
        content.setPadding(new Insets(30));
        content.setAlignment(Pos.TOP_CENTER);

        Label ordersLabel = new Label("ALL ORDERS");
        ordersLabel.setTextFill(Color.WHITE);
        ordersLabel.setFont(new Font(28));
        content.getChildren().add(ordersLabel);

        // ===== Fetch Firestore Orders and Display =====
        try {
            List<Map<String, Object>> orders = firebaseconfig.getAllProductsForCustomer();
            if (orders.isEmpty()) {
                Label emptyLabel = new Label("No Orders Found!");
                emptyLabel.setTextFill(Color.LIGHTGRAY);
                emptyLabel.setFont(new Font(22));
                content.getChildren().add(emptyLabel);
            } else {
                for (Map<String, Object> order : orders) {
                   // String time = order.containsKey("time") ? "9.00pm" : "N/A";
                    String items = order.containsKey("name") ? order.get("name").toString() : "Unknown";
                    String price = order.containsKey("price") ? "₹" + order.get("price").toString() : "₹0";
                    String address = order.containsKey("address") ? order.get("address").toString() : "Pending";
                     String rating = order.containsKey("rating") ? order.get("rating").toString() : "Pending";
                    content.getChildren().add(createOrderCard( items, price, address,rating));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Label errorLabel = new Label("Error fetching orders.");
            errorLabel.setTextFill(Color.RED);
            content.getChildren().add(errorLabel);
        }

        // Scrollable
        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        scrollPane.setPrefHeight(800);
        scrollPane.setPadding(new Insets(10));

        root.setCenter(scrollPane);

        // SCENE
        Scene scene = new Scene(root, 1900, 1000);
        stage.setScene(scene);
        stage.setTitle("Orders Page - NGO Women");
        stage.show();
    }

    // ===== Helper: Order Card =====
    private VBox createOrderCard(String time, String items, String price, String status) {
        VBox card = new VBox(15);
        card.setPadding(new Insets(20));
        card.setStyle("-fx-background-color: #2b1243; -fx-background-radius: 15;");
        card.setMaxWidth(900);
        card.setAlignment(Pos.CENTER_LEFT);

        Label timeLabel = createLabel("⏰ Time: " + time, 18);
        Label itemLabel = createLabel("👜 Products: " + items, 20);
        Label priceLabel = createLabel("💵 Total: " + price, 20);
        Label statusLabel = createLabel("📦 Status: " + status, 18);
        statusLabel.setTextFill(status.equalsIgnoreCase("Completed") ? Color.LIGHTGREEN : Color.ORANGE);

        Button changeStatusBtn = new Button("✅ Mark as Completed");
        styleButton(changeStatusBtn, "#4CAF50", 250, 50);

        changeStatusBtn.setOnAction(e -> {
            statusLabel.setText("📦 Status: Completed");
            statusLabel.setTextFill(Color.LIGHTGREEN);
            // TODO: update Firestore status field if required
        });

        card.getChildren().addAll(timeLabel, itemLabel, priceLabel, statusLabel, changeStatusBtn);
        return card;
    }

    // ===== Helper: Label Styling =====
    private Label createLabel(String text, int fontSize) {
        Label label = new Label(text);
        label.setTextFill(Color.WHITE);
        label.setFont(new Font(fontSize));
        return label;
    }

    // ===== Helper: Button Styling =====
    private void styleButton(Button btn, String color, int width, int height) {
        btn.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; " +
                "-fx-font-size: 18; -fx-background-radius: 10;");
        btn.setPrefWidth(width);
        btn.setPrefHeight(height);
    }
}
