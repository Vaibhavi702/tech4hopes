/*package com.bts.view.Restaurant;





import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class CreateProfilepageNgoWomen {

    public void show(Stage stage) {
        // 🔙 Back Button
        Button backButton = new Button("←");
        backButton.setStyle("-fx-background-color: transparent; -fx-font-size: 22px; -fx-text-fill: #333;");
        backButton.setOnAction(e ->
         stage.close());

        HBox topBar = new HBox(backButton);
        topBar.setAlignment(Pos.TOP_LEFT);
        topBar.setPadding(new Insets(20, 0, 0, 20));

        // 👤 Profile Picture Circle
        ImageView profilePic = new ImageView(new Image(""));
        profilePic.setFitHeight(150);
        profilePic.setFitWidth(150);
        profilePic.setStyle("-fx-background-radius: 75; -fx-border-radius: 75; -fx-border-color: #ddd; -fx-border-width: 3;");

        // 🏷 Title
        Label titleLabel = new Label("NGO Women Profile");
        titleLabel.setFont(Font.font("Arial", 30));
        titleLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        // ✍️ Input Fields
        TextField firstNameField = createInput("First Name");
        TextField lastNameField = createInput("Last Name");
        TextField emailField = createInput("Email");
        TextField phoneField = createInput("Phone Number");

        // 📆 Birth Year Dropdown
        ComboBox<String> birthDropdown = new ComboBox<>();
        birthDropdown.setPromptText("Birth Year");
        birthDropdown.getItems().addAll("1995", "1996", "1997", "1998", "1999", "2000");

        // 👤 Gender Dropdown
        ComboBox<String> genderDropdown = new ComboBox<>();
        genderDropdown.setPromptText("Gender");
        genderDropdown.getItems().addAll("Female", "Other");

        // ✅ Save Button
        Button saveButton = new Button("Save Profile");
        saveButton.setPrefHeight(50);
        saveButton.setPrefWidth(300);
        saveButton.setStyle(
                "-fx-background-color: #8e44ad; -fx-text-fill: white; -fx-font-size: 18px; -fx-background-radius: 30;"
        );

        // 📦 Form Box (Includes all fields)
        VBox formBox = new VBox(20, profilePic, titleLabel, firstNameField, lastNameField,
                emailField, phoneField, birthDropdown, genderDropdown, saveButton);
        formBox.setAlignment(Pos.TOP_CENTER);
        formBox.setPadding(new Insets(40));
        formBox.setMaxWidth(500);

        // 🧾 Card Container
        VBox card = new VBox(10, topBar, formBox);
        card.setAlignment(Pos.TOP_CENTER);
        card.setStyle(
                "-fx-background-color: #fef5ff; -fx-background-radius: 20; " +
                        "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 20, 0, 0, 8);"
        );
        card.setPadding(new Insets(40));
        card.setPrefHeight(950);
        card.setPrefWidth(600);

        // 🌐 Main Layout
        StackPane root = new StackPane(card);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #fdf2ff, #f8e6ff);");

        // 📺 Scene
        Scene scene = new Scene(root, 1900, 1100);
        stage.setTitle("NGO Women Profile");
        stage.setScene(scene);
        stage.show();
    }

    private TextField createInput(String prompt) {
        TextField field = new TextField();
        field.setPromptText(prompt);
        field.setPrefHeight(50);
        field.setStyle("-fx-font-size: 18px;");
        return field;
    }
}
*/
package com.bts.view.Restaurant;

import com.bts.service.firebaseconfig;

import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class CreateProfilepageNgoWomen {

    public void show(Stage stage) {
        stage.setTitle("NGO Women Registration - HopeBridge");

        // 👤 Circular Profile Image
        Image image = new Image(getClass().getResource("/images/ngowomen.jpg").toExternalForm());
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(120);
        imageView.setFitHeight(120);

        Circle circle = new Circle(60, 60, 60);
        imageView.setClip(circle);

        StackPane imageContainer = new StackPane(imageView);
        imageContainer.setPadding(new Insets(10));
        imageContainer.setAlignment(Pos.CENTER);

        // 🔤 Title
        Label title = new Label("NGO Women Registration");
        title.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        // 🧾 Input Fields with larger font & padding
        TextField nameField = new TextField();
        nameField.setPromptText("Full Name");
        nameField.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        emailField.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        TextField phoneField = new TextField();
        phoneField.setPromptText("Phone Number");
        phoneField.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        TextField skillsField = new TextField();
        skillsField.setPromptText("Skills / Expertise");
        skillsField.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        TextField ngoNameField = new TextField();
        ngoNameField.setPromptText("NGO Name");
        ngoNameField.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        TextField locationField = new TextField();
        locationField.setPromptText("Location / Address");
        locationField.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        // ✅ Bigger Register Button
        Button registerBtn = new Button("Register");
        registerBtn.setStyle("-fx-background-color: #8e44ad; -fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;");
        registerBtn.setPrefWidth(300);
        registerBtn.setPrefHeight(55);

       

        // ⬅️ Bigger Back Button
        Button backBtn = new Button("Back");
        backBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: #2980b9; -fx-font-size: 18px; -fx-font-weight: bold;");
        backBtn.setPrefWidth(300);
        backBtn.setPrefHeight(50);
        backBtn.setOnAction(e -> stage.close());

        VBox form = new VBox(15, title, nameField, emailField, phoneField, skillsField, ngoNameField, locationField, registerBtn, backBtn);
        form.setAlignment(Pos.CENTER);
        form.setPadding(new Insets(30));
        form.setMaxWidth(400);
        form.setStyle("-fx-background-color: white; -fx-background-radius: 20; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 10, 0, 0, 8);");

        StackPane box = new StackPane(form);
        box.setPadding(new Insets(20));

        VBox root = new VBox(30, imageContainer, box);
        root.setAlignment(Pos.TOP_CENTER);
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #f5eef8, #ffffff);");
        root.setPadding(new Insets(40));

        // ✨ Box Slide & Fade Animation
        TranslateTransition slide = new TranslateTransition(Duration.seconds(0.8), box);
        slide.setFromY(50);
        slide.setToY(0);
        slide.setCycleCount(1);
        slide.play();

        FadeTransition fade = new FadeTransition(Duration.seconds(1.0), box);
        fade.setFromValue(0);
        fade.setToValue(1);
        fade.play();

         registerBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {
                try {

                    firebaseconfig.storeProfile(nameField.getText(), emailField.getText(), phoneField.getText(), skillsField.getText(), ngoNameField.getText(), locationField.getText());
                    new RestaurantDashboardPage().show((Stage) root.getScene().getWindow());
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
            
        });

        // Set Scene to 1900 x 1000
        Scene scene = new Scene(root, 1900, 1000);
        stage.setScene(scene);
        stage.show();
    }
    
}


