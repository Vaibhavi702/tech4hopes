package com.bts.view.Customer;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.bts.service.firebaseconfig;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CartPage {

    private Label totalLabel = new Label("Total: ₹ 0");
    private VBox cartItemsBox = new VBox(30); // More spacing

    public void show(Stage stage) {

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #fcfcfc;");

        // ===== TOP NAVBAR =====
        HBox navbar = new HBox(30);
        navbar.setPadding(new Insets(30, 50, 30, 50));
        navbar.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e6e6e6; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 6, 0, 0, 2);");
        navbar.setAlignment(Pos.CENTER_LEFT);

        Label back = new Label("← Back");
        back.setFont(Font.font("Arial", 26));
        back.setTextFill(Color.ORANGE);
        back.setOnMouseClicked(e -> {
            try {
                new CustomerDashboardPage().show(stage);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        });

        Label logo = new Label("Your Craft Cart");
        logo.setFont(Font.font("Arial", 34));
        logo.setTextFill(Color.ORANGE);

        navbar.getChildren().addAll(back, logo);

        // ===== CART ITEMS LIST =====
        cartItemsBox.setPadding(new Insets(30));
        cartItemsBox.setAlignment(Pos.CENTER);

        ScrollPane cartScroll = new ScrollPane(cartItemsBox);
        cartScroll.setFitToWidth(true);
        cartScroll.setStyle("-fx-background:white;");

        // ===== CART SUMMARY (TOTAL) =====
        VBox cartSummary = new VBox(20);
        cartSummary.setPadding(new Insets(35, 50, 35, 50));
        cartSummary.setAlignment(Pos.CENTER_RIGHT);
        cartSummary.setStyle("-fx-background-color: #ffffff; -fx-border-color: #e6e6e6; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.05), 8, 0, 0, -2);");

        totalLabel.setFont(Font.font("Arial", 28));
        totalLabel.setTextFill(Color.ORANGE);

        Button checkoutBtn = new Button("Confirm Payement");
        checkoutBtn.setStyle("-fx-background-color: orange; -fx-text-fill: white; -fx-font-size: 22; -fx-font-weight: bold; -fx-background-radius: 10;");
        checkoutBtn.setPrefWidth(380);
        checkoutBtn.setPrefHeight(65);

        // Hover effect
        checkoutBtn.setOnMouseEntered(e -> checkoutBtn.setStyle("-fx-background-color: #ff8c00; -fx-text-fill: white; -fx-font-size: 22; -fx-font-weight: bold; -fx-background-radius: 10;"));
        checkoutBtn.setOnMouseExited(e -> checkoutBtn.setStyle("-fx-background-color: orange; -fx-text-fill: white; -fx-font-size: 22; -fx-font-weight: bold; -fx-background-radius: 10;"));

        checkoutBtn.setOnAction(e -> {
            new CheckoutPage().show(stage);
        });

        cartSummary.getChildren().addAll(totalLabel, checkoutBtn);

        // Root sections
        root.setTop(navbar);
        root.setCenter(cartScroll);
        root.setBottom(cartSummary);

        Scene scene = new Scene(root, 1900, 1000); // Bigger window
        stage.setScene(scene);
        stage.setTitle("Your Craft Cart");
        stage.show();

        // Fetch data from Firestore dynamically
        fetchCartData();
    }

    /**
     * Fetch customer data from Firestore and add to cartItemsBox
     */
    private void fetchCartData() {
        // Clear old items
        cartItemsBox.getChildren().clear();

        new Thread(() -> {
            try {
                List<Map<String, Object>> customers =firebaseconfig.getAllProductsForCustomer();

                for (Map<String, Object> customer : customers) {
                    String name = customer.get("name") != null ? customer.get("name").toString() : "Unknown Item";
                    int price = customer.get("price") != null ? Integer.parseInt(customer.get("price").toString()) : 0;
                    String imageUrl = customer.get("imageUrl") != null ? customer.get("imageUrl").toString() : "/images/ppp1.jpg";

                    Platform.runLater(() -> {
                        cartItemsBox.getChildren().add(createCartItem(name, price, imageUrl));
                        updateTotal();
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    // ===== Create Each Cart Item =====
    private HBox createCartItem(String name, int priceValue, String imgPath) {
        HBox cartCard = new HBox(40);
        cartCard.setStyle("-fx-border-color: #e6e6e6; -fx-background-color: #ffffff; -fx-background-radius: 15; -fx-padding: 30; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.06), 10, 0, 0, 2);");
        cartCard.setAlignment(Pos.CENTER_LEFT);

        // Item Image
        ImageView itemImage = new ImageView();
        try {
            if (imgPath.startsWith("http")) {
                itemImage.setImage(new Image(imgPath)); // URL image
            } else {
                itemImage.setImage(new Image(getClass().getResourceAsStream(imgPath))); // Local image
            }
        } catch (Exception e) {
            itemImage.setImage(new Image(getClass().getResourceAsStream("/images/default.jpg")));
        }
        itemImage.setFitWidth(160);
        itemImage.setFitHeight(140);

        VBox itemDetails = new VBox(15);

        Label itemName = new Label(name);
        itemName.setFont(Font.font("Arial", 26));

        Label price = new Label("₹ " + priceValue);
        price.setFont(Font.font("Arial", 24));
        price.setTextFill(Color.DARKGREEN);

        // Action buttons
        HBox actionBox = new HBox(15);
        Button minus = new Button("-");
        minus.setPrefWidth(45);
        minus.setFont(Font.font(22));

        TextField qty = new TextField("1");
        qty.setPrefWidth(65);
        qty.setAlignment(Pos.CENTER);
        qty.setFont(Font.font(22));

        Button plus = new Button("+");
        plus.setPrefWidth(45);
        plus.setFont(Font.font(22));

        Button remove = new Button("Remove");
        remove.setStyle("-fx-background-color: red; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 8;");
        remove.setFont(Font.font(20));

        // Quantity functionality
        minus.setOnAction(e -> {
            int current = Integer.parseInt(qty.getText());
            if (current > 1) {
                qty.setText(String.valueOf(current - 1));
                updateTotal();
            }
        });

        plus.setOnAction(e -> {
            int current = Integer.parseInt(qty.getText());
            qty.setText(String.valueOf(current + 1));
            updateTotal();
        });

        remove.setOnAction(e -> {
            cartItemsBox.getChildren().remove(cartCard);
            updateTotal();
        });

        actionBox.getChildren().addAll(minus, qty, plus, remove);
        itemDetails.getChildren().addAll(itemName, price, actionBox);

        cartCard.setUserData(new Object[]{priceValue, qty});
        cartCard.getChildren().addAll(itemImage, itemDetails);
        return cartCard;
    }

    // ===== Update Total =====
    private void updateTotal() {
        int total = 0;
        for (javafx.scene.Node node : cartItemsBox.getChildren()) {
            if (node.getUserData() instanceof Object[]) {
                Object[] data = (Object[]) node.getUserData();
                int priceValue = (int) data[0];
                TextField qty = (TextField) data[1];
                total += priceValue * Integer.parseInt(qty.getText());
            }
        }
        totalLabel.setText("Total: ₹ " + total);
    }

    // ===== Firestore Fetch Method =====
//     public static List<Map<String, Object>> getAllCustomer() throws Exception {
//         ApiFuture<QuerySnapshot> future = FirebaseUtil.db.collection("customer").get();
//         List<QueryDocumentSnapshot> documents = future.get().getDocuments();

//         List<Map<String, Object>> customerList = new ArrayList<>();
//         for (QueryDocumentSnapshot document : documents) {
//             customerList.add(document.getData());
//         }
//         return customerList;
//     }
}
// }
