package com.bts.view.Restaurant;

import java.util.List;
import java.util.Map;

import com.bts.service.firebaseconfig;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class RestaurantDashboardPage {

    public void show(Stage stage) throws Exception {
        // Root layout
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #1e0932; -fx-padding: 20;");

        // =================== HEADER ===================
        HBox header = new HBox(40);
        header.setAlignment(Pos.CENTER_LEFT);

        // NGO Icon
        Image ngoImage = new Image(getClass().getResource("/images/bitemoji.jpg").toExternalForm());
        ImageView ngoView = new ImageView(ngoImage);
        ngoView.setFitWidth(100);
        ngoView.setFitHeight(100);

        // Welcome Label
        Label welcome = new Label("Welcome Home,\nNGO Women");
        welcome.setTextFill(Color.WHITE);
        welcome.setFont(new Font("Arial", 30));

        // Buttons
        Button addProductBtn = new Button("+ Add Product");
        styleButton(addProductBtn, "#4CAF50");
        addProductBtn.setOnAction(e -> {
            new AddProductPage().show(stage);
        });

        Button startSalesBtn = new Button("Start Receiving Orders");
        styleButton(startSalesBtn, "orange");
        startSalesBtn.setOnAction(e -> {
            new OrdersPage().show(stage);
        });

        Button myProfileBtn = new Button("My Profile");
styleButton(myProfileBtn, "#9C27B0");
myProfileBtn.setOnAction(e -> {
  try {
    new editprofile3().show(stage);
  } catch (Exception e1) {
    // TODO Auto-generated catch block
    e1.printStackTrace();
  }
});


        // Spacer for alignment
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        header.getChildren().addAll(ngoView, welcome, addProductBtn, startSalesBtn, spacer, myProfileBtn);
        BorderPane.setMargin(header, new Insets(10, 10, 20, 10));
        root.setTop(header);

        // =================== MAIN CONTENT ===================
        HBox mainContent = new HBox(40);
        mainContent.setAlignment(Pos.TOP_CENTER);

        // ====== PRODUCT COLUMN ======
        VBox productColumn = new VBox(20);
        Label productLabel = new Label("PRODUCTS");
        productLabel.setTextFill(Color.WHITE);
        productLabel.setFont(new Font(26));
        productColumn.getChildren().add(productLabel);

        // Fetch products from Firestore
        List<Map<String, Object>> data = firebaseconfig.getAllRestaurants();
        if (data.isEmpty()) {
            Label noDataLabel = new Label("No products found!");
            noDataLabel.setTextFill(Color.LIGHTGRAY);
            noDataLabel.setFont(new Font(18));
            productColumn.getChildren().add(noDataLabel);
        } else {
            for (Map<String, Object> restaurant : data) {
                System.out.println("Restaurant Data: " + restaurant); // Debug log

                // Get each field safely
                String name = (String) restaurant.getOrDefault("name", "No Name");
                String price = (String) restaurant.getOrDefault("price", "₹0");
                String type = (String) restaurant.getOrDefault("type", "N/A");

                // Add card
                productColumn.getChildren().add(createProductCard(name, price, type, "/images/ppp2.jpg"));
            }
        }

        // Scroll Products
        ScrollPane productScroll = new ScrollPane(productColumn);
        productScroll.setFitToWidth(true);
        productScroll.setPrefSize(700, 700);
        productScroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

        // ====== ORDERS COLUMN ======
        VBox ordersColumn = new VBox(20);
        Label ordersLabel = new Label("ORDERS");
        ordersLabel.setTextFill(Color.WHITE);
        ordersLabel.setFont(new Font(26));
        ordersColumn.getChildren().add(ordersLabel);

        // Dummy orders for now
        ordersColumn.getChildren().add(createOrderCard("25-07-2024", "11:30 AM", "Handmade Bag", "₹800"));
        ordersColumn.getChildren().add(createOrderCard("26-07-2024", "2:15 PM", "Clay Pot", "₹500"));
        ordersColumn.getChildren().add(createOrderCard("26-07-2024", "4:00 PM", "Woolen Shawl", "₹1200"));
        ordersColumn.getChildren().add(createOrderCard("27-07-2024", "10:30 AM", "Beaded Necklace", "₹300"));

        // Scroll Orders
        ScrollPane orderScroll = new ScrollPane(ordersColumn);
        orderScroll.setFitToWidth(true);
        orderScroll.setPrefSize(800, 700);
        orderScroll.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

        // Add columns to main content
        mainContent.getChildren().addAll(productScroll, orderScroll);
        root.setCenter(mainContent);

        // =================== SCENE ===================
        Scene scene = new Scene(root, 1400, 900);
        stage.setTitle("NGO Women Dashboard");
        stage.setScene(scene);
        stage.show();
    }

    // =================== Helper: Product Card ===================
    private HBox createProductCard(String name, String price, String type, String imagePath) {
        HBox card = new HBox(20);
        card.setPadding(new Insets(15));
        card.setAlignment(Pos.CENTER_LEFT);
        card.setStyle("-fx-background-color: #2b1243; -fx-background-radius: 12;");
        card.setPrefHeight(150);

        // Image
        Image image = new Image(getClass().getResource(imagePath).toExternalForm());
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(120);
        imageView.setFitHeight(120);

        // Details
        VBox details = new VBox(8);
        Label nameLabel = new Label(name);
        nameLabel.setTextFill(Color.WHITE);
        nameLabel.setFont(new Font(18));

        Label priceLabel = new Label(price + " | " + type);
        priceLabel.setTextFill(Color.LIGHTGRAY);
        priceLabel.setFont(new Font(16));

        details.getChildren().addAll(nameLabel, priceLabel);

        // Availability Button
        Button availability = new Button("Available");
        styleButton(availability, "#4CAF50");

        card.getChildren().addAll(imageView, details, availability);
        return card;
    }

    // =================== Helper: Order Card ===================
    private VBox createOrderCard(String date, String time, String itemName, String price) {
        VBox card = new VBox(10);
        card.setPadding(new Insets(15));
        card.setStyle("-fx-background-color: #2b1243; -fx-background-radius: 10;");

        Label dateLabel = new Label("Order Date: " + date + " | Time: " + time);
        dateLabel.setTextFill(Color.WHITE);
        dateLabel.setFont(new Font(16));

        Label itemLabel = new Label("Item: " + itemName + "  |  Price: " + price);
        itemLabel.setTextFill(Color.WHITE);
        itemLabel.setFont(new Font(18));

        Label status = new Label("Item is Ready to Pick");
        status.setTextFill(Color.LIGHTGREEN);
        status.setFont(new Font(16));

        card.getChildren().addAll(dateLabel, itemLabel, status);
        return card;
    }

    // =================== Helper: Style Buttons ===================
    private void styleButton(Button btn, String color) {
        btn.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; " +
                "-fx-font-size: 18; -fx-background-radius: 10; -fx-padding: 12 25;");
    }
}
