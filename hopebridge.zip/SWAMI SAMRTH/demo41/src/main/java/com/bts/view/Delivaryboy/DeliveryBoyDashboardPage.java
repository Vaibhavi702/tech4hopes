package com.bts.view.Delivaryboy;
import com.bts.service.firebaseconfig;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DeliveryBoyDashboardPage {

    private VBox currentOrdersBox;
    private Stage mainStage;

    public void show(Stage stage) {
        this.mainStage = stage;

        // Root Layout
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #3a0ca3, #7209b7);");

        // =================== TOP SECTION ===================
        VBox topSection = new VBox(20);
        topSection.setAlignment(Pos.CENTER_LEFT);
        topSection.setPadding(new Insets(20, 30, 10, 30));

        Label welcomeText = new Label("Hi, Delivery Partner");
        welcomeText.setFont(new Font("Arial", 48));
        welcomeText.setTextFill(Color.WHITE);

        // Navigation Buttons
        HBox navBar = new HBox(30);
        navBar.setAlignment(Pos.CENTER_LEFT);

        Button btnPastOrders = createNavButton("📜 Past Deliveries");
        Button btnProfile = createNavButton("👤 Profile");

        navBar.getChildren().addAll(btnPastOrders, btnProfile);
        topSection.getChildren().addAll(welcomeText, navBar);

        root.setTop(topSection);

        // =================== LEFT SECTION: CURRENT DELIVERIES ===================
        VBox ordersContainer = new VBox(25);
        ordersContainer.setAlignment(Pos.TOP_CENTER);
        ordersContainer.setPadding(new Insets(30, 30, 30, 30));

        Label title = new Label("Current Deliveries");
        title.setFont(new Font("Arial", 38));
        title.setTextFill(Color.WHITE);

        currentOrdersBox = new VBox(30);
        currentOrdersBox.setPadding(new Insets(10));

        ScrollPane scrollPane = new ScrollPane(currentOrdersBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefHeight(700);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");

        ordersContainer.getChildren().addAll(title, scrollPane);

        // =================== RIGHT SECTION: DELIVERY BOY IMAGE FULL ===================
        StackPane imageContainer = new StackPane();
        imageContainer.setAlignment(Pos.CENTER);

        Image deliveryBoyImage = new Image(getClass().getResource("/images/delivaryBoyimages.png").toExternalForm());
        ImageView deliveryBoyView = new ImageView(deliveryBoyImage);
        deliveryBoyView.setPreserveRatio(false);
        deliveryBoyView.setFitWidth(800);   // Full right side
        deliveryBoyView.setFitHeight(900);  // Full screen height

        imageContainer.getChildren().add(deliveryBoyView);

        // =================== MAIN LAYOUT ===================
        HBox centerBox = new HBox(0, ordersContainer, imageContainer);
        centerBox.setAlignment(Pos.CENTER);
        root.setCenter(centerBox);

        // =================== NAVIGATION ===================
        btnPastOrders.setOnAction(e -> new DelivaryBoyPastorderPages().show(mainStage));
       //tnProfile.setOnAction(e -> new CreateProfilePage1().show(mainStage));
         btnProfile.setOnAction(e -> new editprofile2().show(mainStage));

        // =================== SCENE ===================
        Scene scene = new Scene(root, 1900, 1000);
        stage.setTitle("Delivery Partner Dashboard");
        stage.setScene(scene);
        stage.show();

        // =================== FETCH ORDERS FROM FIRESTORE ===================
        fetchCurrentOrders();
    }

    // =================== Fetch Data From Firestore ===================
    private void fetchCurrentOrders() {
        currentOrdersBox.getChildren().clear();

        new Thread(() -> {
            try {
                List<Map<String, Object>> orders =firebaseconfig.getAllProductsForCustomer();

                if (orders.isEmpty()) {
                    Platform.runLater(() -> {
                        Label noOrders = createLabel("No current deliveries found.", 24, Color.WHITE);
                        currentOrdersBox.getChildren().add(noOrders);
                    });
                } else {
                    int index = 0;
                    for (Map<String, Object> order : orders) {
                        String name = order.get("name") != null ? order.get("name").toString() : "Unknown Product";
                        String address = order.get("address") != null ? order.get("address").toString() : "No Address";
                        String price = order.get("price") != null ? "₹" + order.get("price").toString() : "₹0";
                        String rating = order.get("rating") != null ? order.get("rating").toString() : "N/A";

                        String orderId = "ORDER" + (1000 + index); // Hardcoded order ID for now
                        String customer = "Customer " + (index + 1); // Hardcoded customer name for now
                        String date = "15-07-2024"; // Hardcoded date
                        String time = "12:39 PM"; // Hardcoded time

                        Platform.runLater(() -> addCurrentOrder(orderId, name, customer, date, time, price, address));
                        index++;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    // =================== Firestore Data ===================
    // public static List<Map<String, Object>> getAllProductsForCustomer() throws Exception {
    //     String customerEmail = AuthController.getEmail();

    //     ApiFuture<QuerySnapshot> future = FirebaseUtil.db
    //             .collection("customer")
    //             .document(customerEmail)
    //             .collection("prod")
    //             .get();

    //     List<QueryDocumentSnapshot> documents = future.get().getDocuments();
    //     List<Map<String, Object>> productList = new ArrayList<>();

    //     for (QueryDocumentSnapshot document : documents) {
    //         Map<String, Object> data = document.getData();
    //         data.put("id", document.getId());
    //         productList.add(data);
    //     }
    //     return productList;
    // }

    // =================== UI Helper Methods ===================
    private void addCurrentOrder(String orderId, String products, String customer, String date,
                                 String time, String amount, String address) {
        VBox card = new VBox(15);
        card.setPadding(new Insets(25));
        card.setStyle("-fx-background-color: white; -fx-background-radius: 18; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 20, 0, 0, 10);");
        card.setPrefWidth(600);  // Wider card
        card.setPrefHeight(220); // Taller card

        Label lblId = createLabel("Order ID: " + orderId, 20, Color.DARKSLATEGRAY);
        Label lblProducts = createLabel("Products: " + products, 26, Color.BLACK);
        Label lblCustomer = createLabel("Customer: " + customer, 22, Color.DARKBLUE);
        Label lblDate = createLabel("Date: " + date + " | Time: " + time, 20, Color.GRAY);
        Label lblAmount = createLabel("Amount: " + amount, 24, Color.FORESTGREEN);
        Label lblAddress = createLabel("Address: " + address, 20, Color.PURPLE);

        card.getChildren().addAll(lblId, lblProducts, lblCustomer, lblDate, lblAmount, lblAddress);
        currentOrdersBox.getChildren().add(card);
    }

    private Label createLabel(String text, int size, Color color) {
        Label label = new Label(text);
        label.setFont(new Font(size));
        label.setTextFill(color);
        return label;
    }

    private Button createNavButton(String text) {
        Button btn = new Button(text);
        btn.setPrefHeight(65);
        btn.setPrefWidth(280);
        btn.setStyle("-fx-background-color: #ff9800; -fx-text-fill: white; -fx-font-size: 24; " +
                "-fx-font-weight: bold; -fx-background-radius: 30;");
        return btn;
    }
}
