/*package com.bts.view.Customer;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class CreateProfilePage {

    public void show(Stage stage) {
        // 🔙 Back Button
        Button backButton = new Button("←");
        backButton.setStyle("-fx-background-color: transparent; -fx-font-size: 22px; -fx-text-fill: #333;");
        backButton.setOnAction(e -> stage.close());

        HBox topBar = new HBox(backButton);
        topBar.setAlignment(Pos.TOP_LEFT);
        topBar.setPadding(new Insets(20, 0, 0, 20));

        // 👤 Profile Picture Circle
        ImageView profilePic = new ImageView(new Image("https://cdn-icons-png.flaticon.com/512/149/149071.png"));
        profilePic.setFitHeight(150);
        profilePic.setFitWidth(150);
        profilePic.setStyle("-fx-background-radius: 75; -fx-border-radius: 75; -fx-border-color: #ddd; -fx-border-width: 3;");

        // 🏷 Title
        Label titleLabel = new Label("Customer Profile");
        titleLabel.setFont(Font.font("Arial", 30));
        titleLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        // ✍️ Input Fields
        TextField firstNameField = createInput("First Name");
        TextField lastNameField = createInput("Last Name");
        TextField emailField = createInput("Email");
        TextField phoneField = createInput("Phone Number");

        // 📆 Birth Year Dropdown
        ComboBox<String> birthDropdown = new ComboBox<>();
        birthDropdown.setPromptText("Birth Year");
        birthDropdown.getItems().addAll("1999", "2000", "2001", "2002", "2003");

        // 👤 Gender Dropdown
        ComboBox<String> genderDropdown = new ComboBox<>();
        genderDropdown.setPromptText("Gender");
        genderDropdown.getItems().addAll("Male", "Female", "Other");

        // ✅ Save Button
        Button saveButton = new Button("Save Profile");
        saveButton.setPrefHeight(50);
        saveButton.setPrefWidth(300);
        saveButton.setStyle(
                "-fx-background-color: #003366; -fx-text-fill: white; -fx-font-size: 18px; -fx-background-radius: 30;"
        );

        // 📦 Form Box (Includes all fields)
        VBox formBox = new VBox(20, profilePic, titleLabel, firstNameField, lastNameField,
                emailField, phoneField, birthDropdown, genderDropdown, saveButton);
        formBox.setAlignment(Pos.TOP_CENTER);
        formBox.setPadding(new Insets(40));
        formBox.setMaxWidth(500);

        // 🧾 Card Container
        VBox card = new VBox(10, topBar, formBox);
        card.setAlignment(Pos.TOP_CENTER);
        card.setStyle(
                "-fx-background-color: white; -fx-background-radius: 20; " +
                        "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 20, 0, 0, 8);"
        );
        card.setPadding(new Insets(40));
        card.setPrefHeight(950);   // Big card height
        card.setPrefWidth(600);    // Big card width

        // 🌐 Main Layout
        StackPane root = new StackPane(card);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #f2f2f2, #e8e8e8);");

        // 📺 Scene
        Scene scene = new Scene(root, 1900, 1100);
        stage.setTitle("Customer Profile");
        stage.setScene(scene);
        stage.show();
    }

    private TextField createInput(String prompt) {
        TextField field = new TextField();
        field.setPromptText(prompt);
        field.setPrefHeight(50);
        field.setStyle("-fx-font-size: 18px;");
        return field;
    }
}
    */
package com.bts.view.Customer;

import com.bts.view.signup.CustomerSignupPage;

import javafx.animation.FadeTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class CreateProfilePage {

    public void show(Stage stage) {
        stage.setTitle("Customer Registration - HopeBridge");

        // 👤 Circular Profile Image
        Image image = new Image(getClass().getResource("/images/customer.png").toExternalForm());
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(120);
        imageView.setFitHeight(120);
        Circle clip = new Circle(60, 60, 60);
        imageView.setClip(clip);

        StackPane imageContainer = new StackPane(imageView);
        imageContainer.setPadding(new Insets(30));
        imageContainer.setAlignment(Pos.CENTER);

        // 🔲 Form container with enhanced width
        VBox formContent = new VBox(18);
        formContent.setPadding(new Insets(35));
        formContent.setAlignment(Pos.CENTER);
        formContent.setStyle("-fx-background-color: white; -fx-background-radius: 20;");
        formContent.setMaxWidth(500);  // Increased width for large screen
        formContent.setEffect(new DropShadow(12, Color.rgb(0, 0, 0, 0.2)));
        formContent.setOpacity(0); // for transition

        // 🧾 Form Fields
        Label title = new Label("Register as Customer");
        title.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        TextField nameField = new TextField();
        nameField.setPromptText("Full Name");
        nameField.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        emailField.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        TextField phoneField = new TextField();
        phoneField.setPromptText("Phone Number");
        phoneField.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        TextField addressField = new TextField();
        addressField.setPromptText("Address");
        addressField.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        // ✅ Bigger Buttons
        Button registerBtn = new Button("Register");
        registerBtn.setPrefWidth(300);
        registerBtn.setPrefHeight(55);
        registerBtn.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;");

        Button backBtn = new Button("Back");
        backBtn.setPrefWidth(300);
        backBtn.setPrefHeight(50);
        backBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: #2980b9; -fx-font-size: 18px; -fx-font-weight: bold;");
        backBtn.setOnAction(e -> {
    new CustomerSignupPage().show((Stage) backBtn.getScene().getWindow());
});

        formContent.getChildren().addAll(
            title, nameField, emailField, phoneField, addressField, registerBtn, backBtn
        );

        VBox mainBox = new VBox(25, imageContainer, formContent);
        mainBox.setAlignment(Pos.TOP_CENTER);  // Keep top alignment or can be CENTER if you want vertical centering
        mainBox.setPadding(new Insets(50));
        mainBox.setStyle("-fx-background-color: linear-gradient(to bottom right, #d0f0fd, #ffffff);");

        // ✨ Fade-in animation
        FadeTransition boxFade = new FadeTransition(Duration.seconds(1.2), formContent);
        boxFade.setFromValue(0);
        boxFade.setToValue(1);
        boxFade.setDelay(Duration.seconds(0.3));
        boxFade.play();

        // Set screen size to 1900 x 1000
        Scene scene = new Scene(mainBox, 1900, 1000);
        stage.setScene(scene);
        stage.show();
    }
}
