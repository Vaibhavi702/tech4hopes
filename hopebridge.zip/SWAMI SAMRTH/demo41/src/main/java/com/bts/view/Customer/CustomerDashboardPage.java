/*ckage com.bts.view.Customer;

import com.bts.view.login.CustomerLoginPage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class CustomerDashboardPage {

    public void show(Stage stage) {

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #f8f8fc;");

        // ----- TOP NAVBAR -----
        HBox navbar = new HBox(20);
        navbar.setPadding(new Insets(20, 50, 20, 50));
        navbar.setStyle("-fx-background-color: white; -fx-border-color: #ddd; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 6, 0, 0, 2);");
        navbar.setAlignment(Pos.CENTER_LEFT);

        Button btnHome = createNavButton("🏠 Home", "#ff9800");
        Button btnCart = createNavButton("🛒 Cart", "#4CAF50");
        Button btnOrders = createNavButton("📦 Orders", "#2196F3");
        Button btnProfile = createNavButton("👤 My Profile", "#9C27B0");
        Button btnLogout = createNavButton("🚪 Logout", "#f44336");

        btnCart.setOnAction(e -> new CartPage().show(stage));
        btnOrders.setOnAction(e -> new OrdersPage().show(stage));
        btnProfile.setOnAction(e -> {
            System.out.println("Navigate to My Profile Page");
            
           
             //Add navigation to profile page here
        });
        btnLogout.setOnAction(e -> new CustomerLoginPage().show(stage));

        navbar.getChildren().addAll(btnHome, btnCart, btnOrders, btnProfile, btnLogout);

        // ----- HIGHLIGHTED QUOTE -----
        Label quote = new Label("“Empowering Women, One Purchase at a Time!”");
        quote.setFont(Font.font("Arial", 28));
        quote.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");
        quote.setWrapText(true);

        HBox quoteBox = new HBox(quote);
        quoteBox.setAlignment(Pos.CENTER);
        quoteBox.setPadding(new Insets(20));
        quoteBox.setStyle("-fx-background-color: linear-gradient(to right, #6a11cb, #cab421ff); " +
                "-fx-background-radius: 10; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 10, 0, 0, 4);");

        // ----- CATEGORY SCROLLER -----
        HBox categories = new HBox(40);
        categories.setPadding(new Insets(30, 20, 30, 20));
        categories.setAlignment(Pos.CENTER_LEFT);

        String[][] categoryData = {
                {"/images/ppp1.jpg", "Handmade Bags"},
                {"/images/ppp2.jpg", "Jewelry"},
                {"/images/ppp3.jpg", "Home Decor"},
                {"/images/ppp4.jpg", "Sarees"},
                {"/images/ppp5.jpg", "Wooden Crafts"},
                {"/images/ppp6.jpg", "Pottery"}
        };

        for (String[] category : categoryData) {
            VBox box = new VBox(12);
            box.setAlignment(Pos.CENTER);

            Image image = new Image(getClass().getResourceAsStream(category[0]));
            ImageView img = new ImageView(image);
            img.setFitHeight(150);
            img.setFitWidth(150);

            Label label = new Label(category[1]);
            label.setFont(Font.font("Arial", 20));
            label.setStyle("-fx-font-weight: bold;");

            box.getChildren().addAll(img, label);
            categories.getChildren().add(box);
        }

        VBox topSection = new VBox(navbar, quoteBox, categories);

        // ----- PRODUCTS TILEPANE -----
        TilePane productsTile = new TilePane();
        productsTile.setPadding(new Insets(20));
        productsTile.setHgap(20);
        productsTile.setVgap(30);
        productsTile.setPrefColumns(4); // Show 4 per row
        productsTile.setTileAlignment(Pos.TOP_CENTER);

        String bgColor = "#ffffff";

        // Reduced product count: 12
        for (int i = 0; i < 12; i++) {
            VBox productCard = new VBox(12);
            productCard.setPadding(new Insets(15));
            productCard.setAlignment(Pos.TOP_CENTER);

            productCard.setStyle("-fx-background-color: " + bgColor + "; " +
                    "-fx-border-color: #ccc; -fx-background-radius: 12; -fx-border-radius: 12; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.05), 8, 0, 0, 2);");
            productCard.setPrefWidth(240);

            // Product image
            ImageView imageView = new ImageView(new Image(getClass().getResourceAsStream("/images/ppp1.jpg")));
            imageView.setFitHeight(180);
            imageView.setFitWidth(180);
            imageView.setStyle("-fx-background-color: #eee; -fx-background-radius: 8;");
            int productIndex = i;
            imageView.setOnMouseClicked(e -> new ProductDetailPage("Handmade Product " + (productIndex + 1)).show(stage));

            Label name = new Label("Handmade Product " + (i + 1));
            name.setFont(Font.font("Arial", 20));
            name.setStyle("-fx-font-weight: bold;");

            // NGO Address
            Label ngoAddress = new Label("NGO Address: Pune, Maharashtra");
            ngoAddress.setFont(Font.font("Arial", 14));
            ngoAddress.setStyle("-fx-text-fill: #555;");

            // Rating + price (with colored stars)
            Label details = new Label("⭐ 4." + (i % 5) + "   •   ₹" + (150 + i * 10));
            details.setFont(Font.font("Arial", 16));
            details.setStyle("-fx-text-fill: #FFD700;"); // Star rating in gold/yellow

            // Quantity controls
            HBox qtyBox = new HBox(10);
            qtyBox.setAlignment(Pos.CENTER);
            Button btnMinus = new Button("-");
            Label qtyLabel = new Label("1");
            Button btnPlus = new Button("+");

            btnMinus.setPrefSize(32, 32);
            btnPlus.setPrefSize(32, 32);
            qtyLabel.setFont(Font.font(18));

            btnMinus.setOnAction(e -> {
                int qty = Integer.parseInt(qtyLabel.getText());
                if (qty > 1) qtyLabel.setText(String.valueOf(qty - 1));
            });
            btnPlus.setOnAction(e -> {
                int qty = Integer.parseInt(qtyLabel.getText());
                qtyLabel.setText(String.valueOf(qty + 1));
            });
            qtyBox.getChildren().addAll(btnMinus, qtyLabel, btnPlus);

            // Add to Cart Button
            Button btnAddToCart = new Button("Add to Cart");
            btnAddToCart.setFont(Font.font("Arial", 18));
            btnAddToCart.setPrefHeight(45);
            btnAddToCart.setPrefWidth(150);
            btnAddToCart.setStyle("-fx-background-color: #1565c0; -fx-text-fill: white; -fx-background-radius: 8;");
            btnAddToCart.setOnAction(e -> {
                System.out.println(name.getText() + " added to cart (Qty: " + qtyLabel.getText() + ")");
                new CartPage().show(stage);
            });

            // Add elements to product card
            productCard.getChildren().addAll(imageView, name, ngoAddress, details, qtyBox, btnAddToCart);
            productsTile.getChildren().add(productCard);
        }

        ScrollPane productScroll = new ScrollPane(productsTile);
        productScroll.setFitToWidth(true);
        productScroll.setStyle("-fx-background:white;");

        root.setTop(topSection);
        root.setCenter(productScroll);

        Scene scene = new Scene(root,  1900, 1000);
        stage.setTitle("Customer Dashboard");
        stage.setScene(scene);
        stage.show();
    }

    // ===== Helper Method for Navbar Buttons =====
    private Button createNavButton(String text, String color) {
        Button btn = new Button(text);
        btn.setFont(Font.font("Arial", 18));
        btn.setTextFill(Color.WHITE);
        btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 10;");
        btn.setPrefHeight(50);
        btn.setPrefWidth(160);
        return btn;
    }
}*/
package com.bts.view.Customer;

import java.util.List;
import java.util.Map;

import com.bts.service.firebaseconfig;
import com.bts.view.login.CustomerLoginPage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class CustomerDashboardPage {

    public void show(Stage stage) throws Exception {

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #f8f8fc;");

        // ----- TOP NAVBAR -----
        HBox navbar = new HBox(20);
        navbar.setPadding(new Insets(20, 50, 20, 50));
        navbar.setStyle("-fx-background-color: white; -fx-border-color: #ddd; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 6, 0, 0, 2);");
        navbar.setAlignment(Pos.CENTER_LEFT);

        Button btnHome = createNavButton("🏠 Home", "#ff9800");
        Button btnCart = createNavButton("🛒 Cart", "#4CAF50");
        Button btnOrders = createNavButton("📦 Orders", "#2196F3");
        Button btnProfile = createNavButton("👤 My Profile", "#9C27B0");
        Button btnLogout = createNavButton("🚪 Logout", "#f44336");

        // Add navigation logic
        btnCart.setOnAction(e -> new CartPage().show(stage));
        btnOrders.setOnAction(e -> new OrdersPage().show(stage));
        btnProfile.setOnAction(e -> new CreateProfilePage().show(stage));
         btnProfile.setOnAction(e -> new editprofile().show(stage));
        btnLogout.setOnAction(e -> new CustomerLoginPage().show(stage));

        navbar.getChildren().addAll(btnHome, btnCart, btnOrders, btnProfile, btnLogout);

        // ----- HIGHLIGHTED QUOTE -----
        Label quote = new Label("“Empowering Women, One Purchase at a Time!”");
        quote.setFont(Font.font("Arial", 28));
        quote.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");
        quote.setWrapText(true);

        HBox quoteBox = new HBox(quote);
        quoteBox.setAlignment(Pos.CENTER);
        quoteBox.setPadding(new Insets(20));
        quoteBox.setStyle("-fx-background-color: linear-gradient(to right, #6a11cb, #cab421ff); " +
                "-fx-background-radius: 10; -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 10, 0, 0, 4);");

        // ----- CATEGORY SCROLLER -----
        HBox categories = new HBox(40);
        categories.setPadding(new Insets(30, 20, 30, 20));
        categories.setAlignment(Pos.CENTER_LEFT);

        String[][] categoryData = {
                {"/images/ppp1.jpg", "Handmade Bags"},
                {"/images/ppp2.jpg", "Jewelry"},
                {"/images/ppp3.jpg", "Home Decor"},
                {"/images/ppp4.jpg", "Sarees"},
                {"/images/ppp5.jpg", "Wooden Crafts"},
                {"/images/ppp6.jpg", "Pottery"}
        };

        for (String[] category : categoryData) {
            VBox box = new VBox(12);
            box.setAlignment(Pos.CENTER);

            Image image = new Image(getClass().getResourceAsStream(category[0]));
            ImageView img = new ImageView(image);
            img.setFitHeight(150);
            img.setFitWidth(150);

            Label label = new Label(category[1]);
            label.setFont(Font.font("Arial", 20));
            label.setStyle("-fx-font-weight: bold;");

            box.getChildren().addAll(img, label);
            categories.getChildren().add(box);
        }

        VBox topSection = new VBox(navbar, quoteBox, categories);

        // ----- PRODUCTS TILEPANE -----
        TilePane productsTile = new TilePane();
        productsTile.setPadding(new Insets(20));
        productsTile.setHgap(20);
        productsTile.setVgap(30);
        productsTile.setPrefColumns(4); // Show 4 per row
        productsTile.setTileAlignment(Pos.TOP_CENTER);

        String bgColor = "#ffffff";

        // 12 Sample Products
        // for (int i = 0; i < 12; i++) {
        //     VBox productCard = new VBox(12);
        //     productCard.setPadding(new Insets(15));
        //     productCard.setAlignment(Pos.TOP_CENTER);

        //     productCard.setStyle("-fx-background-color: " + bgColor + "; " +
        //             "-fx-border-color: #ccc; -fx-background-radius: 12; -fx-border-radius: 12; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.05), 8, 0, 0, 2);");
        //     productCard.setPrefWidth(240);

        //     // Product image
        //     ImageView imageView = new ImageView(new Image(getClass().getResourceAsStream("/images/ppp1.jpg")));
        //     imageView.setFitHeight(180);
        //     imageView.setFitWidth(180);
        //     imageView.setStyle("-fx-background-color: #eee; -fx-background-radius: 8;");
        //     int productIndex = i;
        //     imageView.setOnMouseClicked(e -> new ProductDetailPage("Handmade Product " + (productIndex + 1)).show(stage));

        //     Label name = new Label("Handmade Product " + (i + 1));
        //     name.setFont(Font.font("Arial", 20));
        //     name.setStyle("-fx-font-weight: bold;");

        //     // NGO Address
        //     Label ngoAddress = new Label("NGO Address: Pune, Maharashtra");
        //     ngoAddress.setFont(Font.font("Arial", 14));
        //     ngoAddress.setStyle("-fx-text-fill: #555;");

        //     // Rating + price
        //     Label details = new Label("⭐ 4." + (i % 5) + "   •   ₹" + (150 + i * 10));
        //     details.setFont(Font.font("Arial", 16));
        //     details.setStyle("-fx-text-fill: #FFD700;");

        //     // Quantity controls
        //     HBox qtyBox = new HBox(10);
        //     qtyBox.setAlignment(Pos.CENTER);
        //     Button btnMinus = new Button("-");
        //     Label qtyLabel = new Label("1");
        //     Button btnPlus = new Button("+");

        //     btnMinus.setPrefSize(32, 32);
        //     btnPlus.setPrefSize(32, 32);
        //     qtyLabel.setFont(Font.font(18));

        //     btnMinus.setOnAction(e -> {
        //         int qty = Integer.parseInt(qtyLabel.getText());
        //         if (qty > 1) qtyLabel.setText(String.valueOf(qty - 1));
        //     });
        //     btnPlus.setOnAction(e -> {
        //         int qty = Integer.parseInt(qtyLabel.getText());
        //         qtyLabel.setText(String.valueOf(qty + 1));
        //     });
        //     qtyBox.getChildren().addAll(btnMinus, qtyLabel, btnPlus);

        //     // Add to Cart Button
        //     Button btnAddToCart = new Button("Add to Cart");
        //     btnAddToCart.setFont(Font.font("Arial", 18));
        //     btnAddToCart.setPrefHeight(45);
        //     btnAddToCart.setPrefWidth(150);
        //     btnAddToCart.setStyle("-fx-background-color: #1565c0; -fx-text-fill: white; -fx-background-radius: 8;");
        //     btnAddToCart.setOnAction(e -> {
        //         System.out.println(name.getText() + " added to cart (Qty: " + qtyLabel.getText() + ")");
        //        // firebaseconfig.storeProd(bgColor, bgColor, bgColor);
        //         new CartPage().show(stage);
        //     });

        //     // Add elements to product card
        //     productCard.getChildren().addAll(imageView, name, ngoAddress, details, qtyBox, btnAddToCart);
        //     productsTile.getChildren().add(productCard);
        // }

        // Fetch restaurant data from Firestore
List<Map<String, Object>> restaurants = firebaseconfig.getAllRestaurants();

// Iterate through Firestore data instead of 12 static products
for (Map<String, Object> restaurant : restaurants) {
    VBox productCard = new VBox(12);
    productCard.setPadding(new Insets(15));
    productCard.setAlignment(Pos.TOP_CENTER);

    productCard.setStyle("-fx-background-color: " + bgColor + "; " +
            "-fx-border-color: #ccc; -fx-background-radius: 12; -fx-border-radius: 12; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.05), 8, 0, 0, 2);");
    productCard.setPrefWidth(240);

    // Firestore data fields
    String nameStr = restaurant.get("name") != null ? restaurant.get("name").toString() : "Unknown Product";
    String addressStr = restaurant.get("address") != null ? restaurant.get("address").toString() : "No Address";
    String priceStr = restaurant.get("price") != null ? restaurant.get("price").toString() : "100";
    String imageUrl = restaurant.get("imageUrl") != null ? restaurant.get("imageUrl").toString() : "/images/ppp1.jpg";
    String ratingStr = restaurant.get("rating") != null ? restaurant.get("rating").toString() : "4.0";

    // Product image (from URL or default)
    ImageView imageView;
    try {
        if (imageUrl.startsWith("http")) {
            imageView = new ImageView(new Image(imageUrl));
        } else {
            imageView = new ImageView(new Image(getClass().getResourceAsStream(imageUrl)));
        }
    } catch (Exception e) {
        imageView = new ImageView(new Image(getClass().getResourceAsStream("/images/default.jpg")));
    }
    imageView.setFitHeight(180);
    imageView.setFitWidth(180);
    imageView.setStyle("-fx-background-color: #eee; -fx-background-radius: 8;");
    imageView.setOnMouseClicked(e -> new ProductDetailPage(nameStr).show(stage));

    Label name = new Label(nameStr);
    name.setFont(Font.font("Arial", 20));
    name.setStyle("-fx-font-weight: bold;");

    Label ngoAddress = new Label("NGO Address: " + addressStr);
    ngoAddress.setFont(Font.font("Arial", 14));
    ngoAddress.setStyle("-fx-text-fill: #555;");

    Label details = new Label("⭐ " + ratingStr + "   •   ₹" + priceStr);
    details.setFont(Font.font("Arial", 16));
    details.setStyle("-fx-text-fill: #FFD700;");

    // Quantity controls
    HBox qtyBox = new HBox(10);
    qtyBox.setAlignment(Pos.CENTER);
    Button btnMinus = new Button("-");
    Label qtyLabel = new Label("1");
    Button btnPlus = new Button("+");

    btnMinus.setPrefSize(32, 32);
    btnPlus.setPrefSize(32, 32);
    qtyLabel.setFont(Font.font(18));

    btnMinus.setOnAction(e -> {
        int qty = Integer.parseInt(qtyLabel.getText());
        if (qty > 1) qtyLabel.setText(String.valueOf(qty - 1));
    });
    btnPlus.setOnAction(e -> {
        int qty = Integer.parseInt(qtyLabel.getText());
        qtyLabel.setText(String.valueOf(qty + 1));
    });
    qtyBox.getChildren().addAll(btnMinus, qtyLabel, btnPlus);

    // Add to Cart Button
    Button btnAddToCart = new Button("Add to Cart");
    btnAddToCart.setFont(Font.font("Arial", 18));
    btnAddToCart.setPrefHeight(45);
    btnAddToCart.setPrefWidth(150);
    btnAddToCart.setStyle("-fx-background-color: #1565c0; -fx-text-fill: white; -fx-background-radius: 8;");
    btnAddToCart.setOnAction(e -> {
        System.out.println(name.getText() + " added to cart (Qty: " + qtyLabel.getText() + ")");

        try {
            firebaseconfig.storeProd((String)restaurant.get("name"),(String)restaurant.get("address"),(String)restaurant.get("price"),(String)restaurant.get("rating"));
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        new CartPage().show(stage);
    });

    // Add elements to product card
    productCard.getChildren().addAll(imageView, name, ngoAddress, details, qtyBox, btnAddToCart);
    productsTile.getChildren().add(productCard);
}



        ScrollPane productScroll = new ScrollPane(productsTile);
        productScroll.setFitToWidth(true);
        productScroll.setStyle("-fx-background:white;");

        root.setTop(topSection);
        root.setCenter(productScroll);

        Scene scene = new Scene(root, 1900, 1000);
        stage.setTitle("Customer Dashboard");
        stage.setScene(scene);
        stage.show();
    }

    // ===== Helper Method for Navbar Buttons =====
    private Button createNavButton(String text, String color) {
        Button btn = new Button(text);
        btn.setFont(Font.font("Arial", 18));
        btn.setTextFill(Color.WHITE);
        btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 10;");
        btn.setPrefHeight(50);
        btn.setPrefWidth(160);
        return btn;
    }
}


