package com.bts.view.Customer;

import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.QueryDocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import com.bts.service.firebaseconfig;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class OrdersPage {

    public void show(Stage stage) {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: linear-gradient(to bottom, #fdfbfb, #ebedee);");

        // ====== TOP NAVIGATION BUTTONS ======
        HBox topBar = new HBox(20);
        topBar.setPadding(new Insets(15));
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setStyle("-fx-background-color: white; -fx-border-color: #ddd; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 6, 0, 0, 3);");

        Button btnHome = createNavButton("🏠 HOME", "#ff9800");
        Button btnOffers = createNavButton("💎 OFFERS", "#4CAF50");
        Button btnHelp = createNavButton("❓ HELP", "#2196F3");
        Button btnOrders = createNavButton("📦 ORDERS", "#9C27B0");
        Button btnLogout = createNavButton("🚪 LOGOUT", "#f44336");

        topBar.getChildren().addAll(btnHome, btnOffers, btnHelp, btnOrders, btnLogout);
        root.setTop(topBar);

        // ====== TAB FOR CURRENT ORDERS & ORDER HISTORY ======
        TabPane tabPane = new TabPane();
        tabPane.setTabMinWidth(200);
        tabPane.setStyle("-fx-tab-min-height: 45; -fx-background-radius: 10;");

        Tab currentOrdersTab = new Tab("🟢 Current Orders");
        Tab orderHistoryTab = new Tab("📜 Order History");
        currentOrdersTab.setClosable(false);
        orderHistoryTab.setClosable(false);
        tabPane.getTabs().addAll(currentOrdersTab, orderHistoryTab);

        // ====== CURRENT ORDERS LAYOUT ======
        ScrollPane currentOrdersScroll = new ScrollPane();
        currentOrdersScroll.setFitToWidth(true);
        VBox currentOrdersBox = new VBox(20);
        currentOrdersBox.setPadding(new Insets(20));

        // ====== ORDER HISTORY LAYOUT ======
        ScrollPane historyScroll = new ScrollPane();
        historyScroll.setFitToWidth(true);
        VBox historyBox = new VBox(20);
        historyBox.setPadding(new Insets(20));

        // Add "No data" text initially
        currentOrdersBox.getChildren().add(new Label("Loading current orders..."));

        // Set tabs in UI
        currentOrdersScroll.setContent(currentOrdersBox);
        historyScroll.setContent(historyBox);

        currentOrdersTab.setContent(currentOrdersScroll);
        orderHistoryTab.setContent(historyScroll);

        root.setCenter(tabPane);

        Scene scene = new Scene(root, 1900, 1000);
        stage.setScene(scene);
        stage.setTitle("Customer Orders - NGO Project");
        stage.show();

        // Fetch product data from Firestore
        fetchOrders(currentOrdersBox, historyBox);
    }

    // ====== FETCH PRODUCTS FROM CUSTOMER COLLECTION ======
    private void fetchOrders(VBox currentOrdersBox, VBox historyBox) {
        currentOrdersBox.getChildren().clear();

        new Thread(() -> {
            try {
                List<Map<String, Object>> products =firebaseconfig.getAllProductsForCustomer();

                if (products.isEmpty()) {
                    Platform.runLater(() -> currentOrdersBox.getChildren().add(new Label("No current orders.")));
                } else {
                    for (Map<String, Object> product : products) {
                        // Get product details
                        String name = product.get("name") != null ? product.get("name").toString() : "Unknown Product";
                        String priceStr = product.get("price") != null ? product.get("price").toString() : "0";
                        int price = Integer.parseInt(priceStr);

                        // Hardcoded data for order details
                        Order order = new Order(
                                "ORDER" + System.currentTimeMillis(),   // Order ID
                                name + " (Qty: 1)",                     // Product with quantity
                                "Delivery Person",                      // Delivery person name
                                "01-08-2024",                           // Date
                                "10:30 AM",                             // Time
                                "Pune, Maharashtra",                    // Address
                                "Cash on Delivery",                     // Payment mode
                                price,                                  // Subtotal
                                50,                                     // Delivery charge
                                "Arriving"                              // Status
                        );

                        Platform.runLater(() -> currentOrdersBox.getChildren().add(createReceiptCard(order, true)));
                    }
                }

                // Hardcode history (optional)
                Order pastOrder = new Order(
                        "ORDER123456",
                        "Sample Past Order (Qty: 1)",
                        "Mansi",
                        "20-07-2024",
                        "01:00 PM",
                        "Mumbai, Maharashtra",
                        "Card Payment",
                        250,
                        0,
                        "Completed"
                );
                Platform.runLater(() -> historyBox.getChildren().add(createReceiptCard(pastOrder, false)));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    // ====== CREATE RECEIPT CARD (with details) ======
    private VBox createReceiptCard(Order order, boolean isCurrent) {
        VBox receiptCard = new VBox(12);
        receiptCard.setPadding(new Insets(15));
        receiptCard.setStyle("-fx-background-color: white; -fx-background-radius: 14; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 8, 0, 0, 4);");

        // Top Row: Image & Title
        HBox topRow = new HBox(20);
        topRow.setAlignment(Pos.CENTER_LEFT);

        ImageView productImage = new ImageView();
        productImage.setFitHeight(90);
        productImage.setFitWidth(90);
        productImage.setStyle("-fx-background-color: #f0f0f0; -fx-background-radius: 10;");

        VBox infoBox = new VBox(6);
        Label productName = new Label(order.product);
        productName.setFont(Font.font("Arial", 18));
        productName.setStyle("-fx-font-weight: bold;");

        Label orderId = new Label("Order ID: " + order.id);
        orderId.setFont(Font.font("Arial", 14));
        orderId.setTextFill(Color.GRAY);

        Label address = new Label("Delivery Address: " + order.address);
        address.setFont(Font.font(14));

        infoBox.getChildren().addAll(productName, orderId, address);

        topRow.getChildren().addAll(productImage, infoBox);

        // Payment & Status
        Label dateTime = new Label("Date: " + order.date + "   Time: " + order.time);
        dateTime.setTextFill(Color.GRAY);

        Label paymentMode = new Label("Payment Mode: " + order.paymentMode);
        paymentMode.setTextFill(Color.web("#1565c0"));

        Label status = new Label("Status: " + order.status);
        status.setFont(Font.font(15));
        if (order.status.equalsIgnoreCase("Completed")) status.setTextFill(Color.GREEN);
        else if (order.status.equalsIgnoreCase("Arriving")) status.setTextFill(Color.web("#FF9800"));
        else status.setTextFill(Color.web("#2196F3"));

        // Amount breakdown
        Label subtotal = new Label("Subtotal: ₹" + order.subtotal);
        Label delivery = new Label("Delivery Charges: ₹" + order.deliveryCharges);
        Label total = new Label("Total Amount: ₹" + (order.subtotal + order.deliveryCharges));
        total.setStyle("-fx-font-weight: bold; -fx-text-fill: #2e7d32;");

        // Buttons
        HBox actions = new HBox(15);
        actions.setAlignment(Pos.CENTER_LEFT);

        if (isCurrent) {
            Button trackBtn = createActionButton("Track Order", "#FF9800");
            Button cancelBtn = createActionButton("Cancel Order", "#f44336");
            actions.getChildren().addAll(trackBtn, cancelBtn);
        } else {
            Button reorderBtn = createActionButton("Reorder", "#4CAF50");
            Button rateBtn = createActionButton("Rate Order", "#1565c0");
            actions.getChildren().addAll(reorderBtn, rateBtn);
        }

        receiptCard.getChildren().addAll(topRow, dateTime, paymentMode, subtotal, delivery, total, status, actions);
        return receiptCard;
    }

    // ====== NAVBAR BUTTONS ======
    private Button createNavButton(String text, String color) {
        Button btn = new Button(text);
        btn.setFont(Font.font("Arial", 16));
        btn.setTextFill(Color.WHITE);
        btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 8;");
        btn.setPrefWidth(160);
        btn.setPrefHeight(45);
        return btn;
    }

    // ====== ACTION BUTTONS ======
    private Button createActionButton(String text, String color) {
        Button btn = new Button(text);
        btn.setFont(Font.font("Arial", 15));
        btn.setTextFill(Color.WHITE);
        btn.setStyle("-fx-background-color: " + color + "; -fx-background-radius: 8;");
        btn.setPrefWidth(150);
        btn.setPrefHeight(40);
        return btn;
    }

    // ====== ORDER CLASS ======
    static class Order {
        String id, product, deliveryPerson, date, time, address, paymentMode, status;
        int subtotal, deliveryCharges;

        Order(String id, String product, String deliveryPerson, String date, String time,
              String address, String paymentMode, int subtotal, int deliveryCharges, String status) {
            this.id = id;
            this.product = product;
            this.deliveryPerson = deliveryPerson;
            this.date = date;
            this.time = time;
            this.address = address;
            this.paymentMode = paymentMode;
            this.subtotal = subtotal;
            this.deliveryCharges = deliveryCharges;
            this.status = status;
        }
    }

    // ====== FETCH PRODUCTS FROM CUSTOMER'S prod COLLECTION ======
    // public static List<Map<String, Object>> getAllProductsForCustomer() throws Exception {
    //     // Get the logged-in customer email as document ID
    //     String customerEmail = AuthController.getEmail();

    //     // Query the subcollection 'prod' of this customer
    //     ApiFuture<QuerySnapshot> future = FirebaseUtil.db
    //             .collection("customer")
    //             .document(customerEmail)
    //             .collection("prod")
    //             .get();

    //     List<QueryDocumentSnapshot> documents = future.get().getDocuments();

    //     List<Map<String, Object>> productList = new ArrayList<>();
    //     for (QueryDocumentSnapshot document : documents) {
    //         // You can also include document ID if needed
    //         Map<String, Object> data = document.getData();
    //         data.put("id", document.getId()); // Add the document ID for reference
    //         productList.add(data);
    //     }
    //     return productList;
    // }
}
