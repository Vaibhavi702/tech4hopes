package com.bts;

import com.bts.view.signup.CustomerSignupPage;
import com.bts.view.signup.DeliveryBoySignupPage;
import com.bts.view.signup.RestaurantSignupPage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class RoleSelectionPage {

    private final VBox root;

    public RoleSelectionPage() {
        root = new VBox(50);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(60));
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #6A1B9A, #AD1457);");

        // Title - more attractive & bigger
        Label title = new Label("Select Your Role");
        title.setFont(Font.font("Arial", 55)); // bigger size
        title.setTextFill(Color.WHITE);
        title.setStyle("-fx-font-weight: bold;");

        // Glow effect for title
        DropShadow titleShadow = new DropShadow();
        titleShadow.setColor(Color.PINK);
        titleShadow.setRadius(30);
        title.setEffect(titleShadow);

        // Buttons
        Button restaurantBtn = new Button("NGO WOMEN");
        styleButton(restaurantBtn, "#F06292");
        restaurantBtn.setOnAction(e -> {
            System.out.println("Navigating to NGO Women Signup");
            new RestaurantSignupPage().show((Stage) root.getScene().getWindow());
        });

        Button deliveryBoyBtn = new Button("Delivery Boy");
        styleButton(deliveryBoyBtn, "#BA68C8");
        deliveryBoyBtn.setOnAction(e -> {
            System.out.println("Navigating to Delivery Signup");
            new DeliveryBoySignupPage().show((Stage) root.getScene().getWindow());
        });

        Button customerBtn = new Button("Customer");
        styleButton(customerBtn, "#9575CD");
        customerBtn.setOnAction(e -> {
            System.out.println("Navigating to Customer Signup");
            new CustomerSignupPage().show((Stage) root.getScene().getWindow());
        });

        // Add to root
        root.getChildren().addAll(title, restaurantBtn, deliveryBoyBtn, customerBtn);
    }

    private void styleButton(Button btn, String color) {
        btn.setStyle(
                "-fx-font-size: 28px;" + // bigger font
                        "-fx-background-radius: 50px;" +
                        "-fx-padding: 25 80;" + // more padding (bigger button)
                        "-fx-background-color: " + color + ";" +
                        "-fx-text-fill: white;" +
                        "-fx-font-weight: bold;"
        );
        btn.setEffect(new DropShadow(15, Color.DARKGRAY));
        btn.setMaxWidth(450);
    }

    public void show(Stage stage) {
        Scene scene = new Scene(root,  1900, 1000);
        stage.setScene(scene);
        stage.setTitle("HopeBridge - Role Selection");
        stage.show();
    }
}
