package com.bts.view.Delivaryboy;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class DelivaryBoyPastorderPages {

    private VBox pastOrdersBox;
    private Stage mainStage;

    public void show(Stage stage) {
        this.mainStage = stage;

        // Root Layout
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #3a0ca3, #7209b7);");

        // =================== TOP SECTION ===================
        VBox topSection = new VBox(20);
        topSection.setAlignment(Pos.CENTER_LEFT);
        topSection.setPadding(new Insets(20, 30, 10, 30));

        Label welcomeText = new Label("Past Deliveries - Hi, Delivery Partner");
        welcomeText.setFont(new Font("Arial", 42));
        welcomeText.setTextFill(Color.WHITE);

        // Navigation Buttons
        HBox navBar = new HBox(30);
        navBar.setAlignment(Pos.CENTER_LEFT);

        Button btnCurrentOrders = createNavButton("📦 Current Deliveries");
        Button btnProfile = createNavButton("👤 Profile");

        navBar.getChildren().addAll(btnCurrentOrders, btnProfile);
        topSection.getChildren().addAll(welcomeText, navBar);

        root.setTop(topSection);

        // =================== LEFT SECTION: PAST DELIVERIES ===================
        VBox ordersContainer = new VBox(25);
        ordersContainer.setAlignment(Pos.TOP_CENTER);
        ordersContainer.setPadding(new Insets(20, 20, 20, 20));

        Label title = new Label("Past Deliveries");
        title.setFont(new Font("Arial", 38));
        title.setTextFill(Color.WHITE);

        pastOrdersBox = new VBox(30);
        pastOrdersBox.setPadding(new Insets(20));

        // Sample Past Deliveries
        addPastOrder("20240713022246", "Handmade Bag, Wooden Crafts", "Omar",
                "13-07-2024", "02:22 AM", "₹1950", "Saiyad Pune", "Delivered Successfully");
        addPastOrder("20240713150505", "Woolen Shawl", "Praik",
                "12-07-2024", "06:32 PM", "₹1200", "Lake Vistas Society", "Delivered Successfully");
        addPastOrder("20240711184512", "Beaded Necklace, Hand-painted Tray", "Sanya",
                "11-07-2024", "08:45 PM", "₹1750", "Bavdhan, Pune", "Delivered Successfully");

        // ScrollPane
        ScrollPane scrollPane = new ScrollPane(pastOrdersBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        scrollPane.setPrefHeight(700);

        ordersContainer.getChildren().addAll(title, scrollPane);

        // =================== RIGHT SECTION: DELIVERY BOY IMAGE ===================
        StackPane imageContainer = new StackPane();
        imageContainer.setAlignment(Pos.CENTER);

        Image deliveryBoyImage = new Image(getClass().getResource("/images/delivaryBoyimages.png").toExternalForm());
        ImageView deliveryBoyView = new ImageView(deliveryBoyImage);
        deliveryBoyView.setPreserveRatio(false);
        deliveryBoyView.setFitWidth(800);
        deliveryBoyView.setFitHeight(900);

        imageContainer.getChildren().add(deliveryBoyView);

        // =================== MAIN LAYOUT ===================
        HBox centerBox = new HBox(0, ordersContainer, imageContainer);
        centerBox.setAlignment(Pos.CENTER);
        root.setCenter(centerBox);

        // =================== NAVIGATION ===================
        btnCurrentOrders.setOnAction(e -> new DeliveryBoyDashboardPage().show(mainStage));
        // btnProfile.setOnAction(e -> new DeliveryBoyProfilePage().show(mainStage));

        // =================== SCENE ===================
        Scene scene = new Scene(root, 1900, 1000);
        stage.setTitle("Delivery Partner - Past Deliveries");
        stage.setScene(scene);
        stage.show();
    }

    // =================== Helper Methods ===================
    private void addPastOrder(String orderId, String products, String user, String date,
                              String time, String amount, String address, String status) {
        VBox card = new VBox(15);
        card.setPadding(new Insets(25));
        card.setStyle("-fx-background-color: white; -fx-background-radius: 18; " +
                "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 20, 0, 0, 10);");
        card.setPrefWidth(600);
        card.setPrefHeight(240);

        Label lblId = createLabel("Order ID: " + orderId, 20, Color.DARKSLATEGRAY);
        Label lblProducts = createLabel("Products: " + products, 26, Color.BLACK);
        Label lblUser = createLabel("Customer: " + user, 22, Color.DARKBLUE);
        Label lblDate = createLabel("Date: " + date + " | Time: " + time, 20, Color.GRAY);
        Label lblAmount = createLabel("Amount: " + amount, 24, Color.FORESTGREEN);
        Label lblAddress = createLabel("Address: " + address, 20, Color.PURPLE);

        Label lblStatus = createLabel("Status: " + status, 22, Color.GREEN);

        card.getChildren().addAll(lblId, lblProducts, lblUser, lblDate, lblAmount, lblAddress, lblStatus);
        pastOrdersBox.getChildren().add(card);
    }

    private Label createLabel(String text, int size, Color color) {
        Label label = new Label(text);
        label.setFont(new Font(size));
        label.setTextFill(color);
        return label;
    }

    private Button createNavButton(String text) {
        Button btn = new Button(text);
        btn.setPrefHeight(65);
        btn.setPrefWidth(280);
        btn.setStyle("-fx-background-color: #ff9800; -fx-text-fill: white; -fx-font-size: 24; " +
                "-fx-font-weight: bold; -fx-background-radius: 30;");
        return btn;
    }
}


    

