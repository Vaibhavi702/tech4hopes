package com.bts;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class LandingPage extends Application {

    @Override
    public void start(Stage stage) {
        stage.setTitle("TECH4HOPE - Landing Page");

        // Layout
        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setStyle(
                "-fx-background-color: linear-gradient(to bottom right, #263238, #37474F);" + // same as your first code
                        "-fx-padding: 50;"
        );

        // Title Part 1: "Welcome To"
        Label welcomeLabel = new Label("🌉 Welcome To");
        welcomeLabel.setFont(Font.font("Arial", 34));
        welcomeLabel.setTextFill(Color.LIGHTGRAY);

        // Title Part 2: "HopeBridge" - Bigger & Attractive
        Label hopeBridgeLabel = new Label("HopeBridge");
        hopeBridgeLabel.setFont(Font.font("Arial", 75)); // big
        hopeBridgeLabel.setTextFill(Color.WHITE);
        hopeBridgeLabel.setStyle("-fx-font-weight: bold;");

        // Glow Effect for HopeBridge
        DropShadow titleShadow = new DropShadow();
        titleShadow.setColor(Color.CYAN);
        titleShadow.setRadius(30);
        hopeBridgeLabel.setEffect(titleShadow);

        // Tagline
        Label tagline = new Label("Empowering Women • Connecting To The World");
        tagline.setFont(Font.font("Arial", 20));
        tagline.setTextFill(Color.LIGHTYELLOW);

        // Main Button
        Button mainButton = new Button("Get Started");
        mainButton.setStyle(
                "-fx-font-size: 24px;" +
                        "-fx-background-color: linear-gradient(to right, #D81B60, #8E24AA);" + // pink-purple NGO style
                        "-fx-text-fill: white;" +
                        "-fx-background-radius: 40px;" +
                        "-fx-padding: 15 50;" +
                        "-fx-cursor: hand;" +
                        "-fx-font-weight: bold;"
        );

        // Button Glow Effect
        DropShadow buttonShadow = new DropShadow();
        buttonShadow.setColor(Color.PINK);
        buttonShadow.setRadius(20);
        mainButton.setEffect(buttonShadow);

        // Hover Animation
        mainButton.setOnMouseEntered(e -> {
            mainButton.setScaleX(1.08);
            mainButton.setScaleY(1.08);
            mainButton.setStyle(
                    "-fx-font-size: 24px;" +
                            "-fx-background-color: linear-gradient(to right, #E91E63, #9C27B0);" +
                            "-fx-text-fill: white;" +
                            "-fx-background-radius: 40px;" +
                            "-fx-padding: 15 50;" +
                            "-fx-cursor: hand;" +
                            "-fx-font-weight: bold;"
            );
        });
        mainButton.setOnMouseExited(e -> {
            mainButton.setScaleX(1);
            mainButton.setScaleY(1);
            mainButton.setStyle(
                    "-fx-font-size: 24px;" +
                            "-fx-background-color: linear-gradient(to right, #D81B60, #8E24AA);" +
                            "-fx-text-fill: white;" +
                            "-fx-background-radius: 40px;" +
                            "-fx-padding: 15 50;" +
                            "-fx-cursor: hand;" +
                            "-fx-font-weight: bold;"
            );
        });

        // Navigate to Role Selection
        mainButton.setOnAction(e -> {
            RoleSelectionPage roleSelectionPage = new RoleSelectionPage();
            roleSelectionPage.show(stage);
        });

        // Add elements to layout
        root.getChildren().addAll(welcomeLabel, hopeBridgeLabel, tagline, mainButton);

        // Scene
        Scene scene = new Scene(root, 1900, 1000);
        stage.setScene(scene);
        stage.show();
    }
}
