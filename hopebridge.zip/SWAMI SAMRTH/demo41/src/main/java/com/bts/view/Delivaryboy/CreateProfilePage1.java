package com.bts.view.Delivaryboy;

import com.bts.view.signup.CustomerSignupPage;
import com.bts.view.signup.DeliveryBoySignupPage;

import javafx.animation.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class CreateProfilePage1 {

    public void show(Stage stage) {
        stage.setTitle("Delivery Boy Registration - HopeBridge");

        // Profile image
        Image image = new Image(getClass().getResource("/images/deliveryboy.png").toExternalForm());
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(120);
        imageView.setFitHeight(120);

        Circle clip = new Circle(60, 60, 60);
        imageView.setClip(clip);
        StackPane imageContainer = new StackPane(imageView);
        imageContainer.setPadding(new Insets(10));

        // Title
        Label title = new Label("Delivery Boy Registration");
        title.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        // Input fields (bigger fonts & padding)
        TextField name = new TextField();
        name.setPromptText("Full Name");
        name.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        TextField email = new TextField();
        email.setPromptText("Email");
        email.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        TextField phone = new TextField();
        phone.setPromptText("Phone Number");
        phone.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        TextField vehicleNumber = new TextField();
        vehicleNumber.setPromptText("Vehicle Number");
        vehicleNumber.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        TextField city = new TextField();
        city.setPromptText("City / Area");
        city.setStyle("-fx-font-size: 18px; -fx-padding: 12;");

        // Buttons (bigger size)
        Button registerBtn = new Button("Register");
        registerBtn.setPrefWidth(300);
        registerBtn.setPrefHeight(55);
        registerBtn.setStyle("-fx-background-color: #e67e22; -fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;");

        Button backBtn = new Button("Back");
        backBtn.setPrefWidth(300);
        backBtn.setPrefHeight(50);
        backBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: #2980b9; -fx-font-size: 18px; -fx-font-weight: bold;");
        backBtn.setOnAction(e -> 
    new DeliveryBoySignupPage().show((Stage) backBtn.getScene().getWindow())
);


        // Form container
        VBox form = new VBox(15, title, name, email, phone, vehicleNumber, city, registerBtn, backBtn);
        form.setAlignment(Pos.CENTER);
        form.setPadding(new Insets(30));
        form.setMaxWidth(400);

        StackPane formContainer = new StackPane();
        Rectangle bg = new Rectangle(480, 550);
        bg.setArcWidth(40);
        bg.setArcHeight(40);
        bg.setFill(Color.web("#fffaf2"));
        formContainer.getChildren().addAll(bg, form);
        formContainer.setAlignment(Pos.CENTER);

        // Root container
        VBox root = new VBox(30, imageContainer, formContainer);
        root.setAlignment(Pos.TOP_CENTER);
        root.setPadding(new Insets(40));
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #ffe3c9, #ffffff);");

        // Animation
        FadeTransition fade = new FadeTransition(Duration.seconds(1), formContainer);
        fade.setFromValue(0);
        fade.setToValue(1);

        ScaleTransition scale = new ScaleTransition(Duration.seconds(0.8), formContainer);
        scale.setFromX(0.9);
        scale.setFromY(0.9);
        scale.setToX(1);
        scale.setToY(1);

        ParallelTransition transition = new ParallelTransition(fade, scale);
        transition.play();

        // Scene size 1900x1000
        Scene scene = new Scene(root, 1900, 1000);
        stage.setScene(scene);
        stage.show();
    }
}
