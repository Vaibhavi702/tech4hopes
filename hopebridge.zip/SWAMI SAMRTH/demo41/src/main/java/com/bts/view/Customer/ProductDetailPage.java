package com.bts.view.Customer;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class ProductDetailPage {

    private String productName;

    // Constructor
    public ProductDetailPage(String productName) {
        this.productName = productName;
    }

    public void show(Stage stage) {

        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: white;");

        // ----- TOP NAVBAR -----
        HBox navbar = new HBox(20);
        navbar.setPadding(new Insets(15));
        navbar.setStyle("-fx-background-color: #ffffff; -fx-border-color: #ddd;");
        navbar.setAlignment(Pos.CENTER_LEFT);

        Label back = new Label("← Back");
        back.setFont(Font.font("Arial", 18));
        back.setTextFill(Color.ORANGE);
        back.setOnMouseClicked(e -> {
            try {
                new CustomerDashboardPage().show(stage);
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
        });

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label cart = createNavItem("Cart");
        cart.setOnMouseClicked(e -> new CartPage().show(stage));

        navbar.getChildren().addAll(back, spacer, cart);

        // ----- PRODUCT DETAILS SECTION -----
        VBox productDetails = new VBox(20);
        productDetails.setPadding(new Insets(30, 20, 30, 20));
        productDetails.setAlignment(Pos.TOP_CENTER);

        ImageView productImage = new ImageView(new Image(getClass().getResourceAsStream("/images/ppp1.jpg")));
        productImage.setFitHeight(300);   // bigger size for clarity
        productImage.setFitWidth(400);
        productImage.setStyle("-fx-background-color: #eee; -fx-border-color: #ccc; -fx-border-radius: 8;");

        Label name = new Label(productName);
        name.setFont(Font.font("Arial", 28));
        name.setStyle("-fx-font-weight: bold;");

        Label desc = new Label("Beautiful handmade product, ethically sourced and crafted with care. Perfect for daily use or gifting.");
        desc.setWrapText(true);
        desc.setMaxWidth(800);
        desc.setFont(Font.font(17));

        Label price = new Label("₹ 399.00");
        price.setFont(Font.font(20));
        price.setTextFill(Color.DARKGREEN);

        Label rating = new Label("⭐ 4.5 (120 Reviews)");
        rating.setFont(Font.font(16));
        rating.setTextFill(Color.GRAY);

        Button addToCart = new Button("Add to Cart");
        addToCart.setFont(Font.font(18));
        addToCart.setPrefWidth(200);
        addToCart.setPrefHeight(45);
        addToCart.setStyle("-fx-background-color: orange; -fx-text-fill: white; -fx-font-weight: bold;");
        addToCart.setOnAction(e -> new CartPage().show(stage));

        productDetails.getChildren().addAll(productImage, name, desc, price, rating, addToCart);

        // ----- MENU SECTION -----
        Label menuHeading = new Label("Available Variants / Menu");
        menuHeading.setFont(Font.font("Arial", 22));
        menuHeading.setStyle("-fx-font-weight: bold;");
        menuHeading.setPadding(new Insets(10));

        VBox menuItemsBox = new VBox(20);
        menuItemsBox.setPadding(new Insets(15, 40, 30, 40));
        menuItemsBox.setAlignment(Pos.CENTER);

        for (int i = 0; i < 5; i++) {
            HBox menuCard = new HBox(25);
            menuCard.setStyle("-fx-border-color: #ddd; -fx-background-color: #fff; -fx-background-radius: 8;");
            menuCard.setPadding(new Insets(20));
            menuCard.setAlignment(Pos.CENTER_LEFT);
            menuCard.setPrefWidth(900);  // wider card

            ImageView itemImage = new ImageView(new Image(getClass().getResourceAsStream("/images/ppp2.jpg")));
            itemImage.setFitWidth(130);
            itemImage.setFitHeight(100);
            itemImage.setStyle("-fx-background-color: #eee; -fx-border-radius: 6;");

            VBox itemDetails = new VBox(8);
            Label itemName = new Label("Variant " + (i + 1));
            itemName.setFont(Font.font(18));
            Label itemPrice = new Label("₹ " + (300 + i * 50));
            itemPrice.setFont(Font.font(16));
            itemPrice.setTextFill(Color.DARKGREEN);

            // Action box with + - buttons
            HBox actionBox = new HBox(10);
            actionBox.setAlignment(Pos.CENTER_LEFT);

            Button minus = new Button("-");
            TextField qty = new TextField("1");
            Button plus = new Button("+");

            minus.setPrefWidth(35);
            plus.setPrefWidth(35);
            qty.setPrefWidth(50);
            qty.setAlignment(Pos.CENTER);

            minus.setOnAction(e -> {
                int current = Integer.parseInt(qty.getText());
                if (current > 1) qty.setText(String.valueOf(current - 1));
            });

            plus.setOnAction(e -> {
                int current = Integer.parseInt(qty.getText());
                qty.setText(String.valueOf(current + 1));
            });

            Button addButton = new Button("Add to Cart");
            addButton.setFont(Font.font(14));
            addButton.setStyle("-fx-background-color: orange; -fx-text-fill: white;");
            addButton.setOnAction(e -> new CartPage().show(stage));

            actionBox.getChildren().addAll(minus, qty, plus, addButton);

            itemDetails.getChildren().addAll(itemName, itemPrice, actionBox);
            menuCard.getChildren().addAll(itemImage, itemDetails);

            menuItemsBox.getChildren().add(menuCard);
        }

        ScrollPane menuScroll = new ScrollPane(menuItemsBox);
        menuScroll.setFitToWidth(true);
        menuScroll.setStyle("-fx-background:white;");

        VBox fullContent = new VBox(20, productDetails, menuHeading, menuScroll);
        fullContent.setAlignment(Pos.TOP_CENTER);

        root.setTop(navbar);
        root.setCenter(fullContent);

        Scene scene = new Scene(root,  1900, 1000);
        stage.setScene(scene);
        stage.setTitle("Product Details");
        stage.show();
    }

    // Helper for navbar items
    private Label createNavItem(String text) {
        Label label = new Label(text);
        label.setFont(Font.font("Arial", 16));
        label.setTextFill(Color.BLACK);
        label.setOnMouseEntered(e -> label.setTextFill(Color.ORANGE));
        label.setOnMouseExited(e -> label.setTextFill(Color.BLACK));
        return label;
    }
}
